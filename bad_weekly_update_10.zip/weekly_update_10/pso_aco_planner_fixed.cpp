/*
 * =============================================================================
 *  pso_aco_planner_fixed.cpp
 *
 *  COMPARISON VERSION: PSO-optimized vs Fixed alpha/beta/rho
 *  Runs the SAME pipeline twice:
 *    1) With PSO-tuned (alpha, beta, rho)
 *    2) With FIXED user-specified (alpha, beta, rho)
 *  Then prints a side-by-side comparison report.
 *
 *  Reference: Wu, Zhou & Xiao, IEEE Access 2020, DOI 10.1109/ACCESS.2020.3028467
 *
 *  Build :  g++ -O2 -std=c++17 -o pso_aco_planner_fixed pso_aco_planner_fixed.cpp
 *  Run   :  ./pso_aco_planner_fixed    (reads config.txt + map_data.csv + sd_pairs.csv)
 * =============================================================================
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <limits>
#include <numeric>
#include <iomanip>
#include <map>
#include <set>
#include <cassert>
#include <utility>

// =============================================================================
//  SECTION 1 -- Data Structures
// =============================================================================

struct Edge {
    int    from, to;
    double length;       // di  (metres)
    int    lanes;        // li
    double road_width;   // physical road width in metres
    double f_current;    // fi(t-1)  vehicles currently on road
    double f_in;         // fin_i(t)
    double f_out;        // fout_i(t)
};

struct VehicleType {
    std::string name;
    double width;              // vehicle width (m)
    double height;             // vehicle height (m)
    double length;             // vehicle length (m)
    int    min_lanes_required; // minimum lanes needed
    double min_road_width;     // minimum road width needed (m)
};

struct Config {
    // Graph
    int    start_node    = 0;
    int    end_node      = 9;
    std::string map_file        = "map_data.csv";
    std::string pairs_file       = "sd_pairs.csv";
    std::string vehicle_types_file = "vehicle_types.csv";

    // Vehicle
    double avg_vehicle_len = 5.0;  // L

    // Dynamic trigger
    double R_max       = 250.0;
    double delta_R_max = 30.0;

    // PSO
    int    pso_swarm   = 30;
    int    pso_iter    = 100;
    double pso_w       = 0.7;
    double pso_c1      = 1.5;
    double pso_c2      = 1.5;
    double alpha_min   = 0.5,  alpha_max = 1.5;
    double beta_min    = 1.0,  beta_max  = 5.0;
    double rho_min     = 0.5,  rho_max   = 1.0;

    // ACO
    int    num_ants    = 10;
    int    aco_iter    = 100;
    double Q_const     = 100.0;
    double tau_init    = 1.0;

    // Simulation
    int    sim_steps      = 20;
    double traffic_noise  = 0.2;
    int    random_seed    = 42;

    // Combined Route Optimization
    int    combined_opt       = 1;     // 0=independent only, 1=run combined
    int    combined_iters     = 5;     // max outer-loop iterations
    double combined_weight    = 0.3;   // traffic accumulation factor
    double stability_thresh   = 0.05;  // convergence threshold (5%)

    // Fixed alpha/beta/rho (for comparison with PSO-tuned values)
    double fixed_alpha = 1.0;   // midpoint of [0.5, 1.5]
    double fixed_beta  = 3.0;   // midpoint of [1.0, 5.0]
    double fixed_rho   = 0.75;  // midpoint of [0.5, 1.0]
};

// Result from a single source-destination pair run
struct PairResult {
    int source, destination;
    std::string vehicle_type;  // type of vehicle for this pair
    double pso_alpha, pso_beta, pso_rho;
    std::vector<int> initial_path;
    double initial_cost;
    std::vector<int> final_path;
    double final_cost;      // total ar (actual traversed cost)
    int replan_count;
    bool reached;
    int edges_blocked;      // count of edges blocked due to vehicle constraint
};

// =============================================================================
//  SECTION 2 -- Config Parser
// =============================================================================

static std::string trim(const std::string& s) {
    size_t l = s.find_first_not_of(" \t\r\n");
    size_t r = s.find_last_not_of(" \t\r\n");
    return (l == std::string::npos) ? "" : s.substr(l, r - l + 1);
}

Config load_config(const std::string& path) {
    Config cfg;
    std::ifstream f(path);
    if (!f.is_open()) {
        std::cerr << "[WARN] Cannot open " << path
                  << " -- using built-in defaults.\n";
        return cfg;
    }

    std::string line;
    while (std::getline(f, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        auto eq = line.find('=');
        if (eq == std::string::npos) continue;

        std::string key = trim(line.substr(0, eq));
        std::string val = trim(line.substr(eq + 1));
        // Strip inline comments
        auto hash = val.find('#');
        if (hash != std::string::npos) val = trim(val.substr(0, hash));

        if (key == "START_NODE")      cfg.start_node       = std::stoi(val);
        else if (key == "END_NODE")   cfg.end_node         = std::stoi(val);
        else if (key == "MAP_FILE")   cfg.map_file         = val;
        else if (key == "PAIRS_FILE") cfg.pairs_file       = val;
        else if (key == "AVG_VEHICLE_LEN") cfg.avg_vehicle_len = std::stod(val);
        else if (key == "R_MAX")           cfg.R_max        = std::stod(val);
        else if (key == "DELTA_R_MAX")     cfg.delta_R_max  = std::stod(val);
        else if (key == "PSO_SWARM_SIZE")  cfg.pso_swarm    = std::stoi(val);
        else if (key == "PSO_ITERATIONS")  cfg.pso_iter     = std::stoi(val);
        else if (key == "PSO_W")           cfg.pso_w        = std::stod(val);
        else if (key == "PSO_C1")          cfg.pso_c1       = std::stod(val);
        else if (key == "PSO_C2")          cfg.pso_c2       = std::stod(val);
        else if (key == "ALPHA_MIN")       cfg.alpha_min    = std::stod(val);
        else if (key == "ALPHA_MAX")       cfg.alpha_max    = std::stod(val);
        else if (key == "BETA_MIN")        cfg.beta_min     = std::stod(val);
        else if (key == "BETA_MAX")        cfg.beta_max     = std::stod(val);
        else if (key == "RHO_MIN")         cfg.rho_min      = std::stod(val);
        else if (key == "RHO_MAX")         cfg.rho_max      = std::stod(val);
        else if (key == "NUM_ANTS")        cfg.num_ants     = std::stoi(val);
        else if (key == "ACO_ITERATIONS")  cfg.aco_iter     = std::stoi(val);
        else if (key == "Q_CONST")         cfg.Q_const      = std::stod(val);
        else if (key == "TAU_INIT")        cfg.tau_init     = std::stod(val);
        else if (key == "SIM_STEPS")       cfg.sim_steps    = std::stoi(val);
        else if (key == "TRAFFIC_NOISE")   cfg.traffic_noise= std::stod(val);
        else if (key == "RANDOM_SEED")     cfg.random_seed  = std::stoi(val);
        else if (key == "PAIRS_FILE")      cfg.pairs_file   = val;
        else if (key == "COMBINED_OPT")    cfg.combined_opt      = std::stoi(val);
        else if (key == "COMBINED_ITERS")  cfg.combined_iters    = std::stoi(val);
        else if (key == "COMBINED_WEIGHT") cfg.combined_weight   = std::stod(val);
        else if (key == "STABILITY_THRESH")cfg.stability_thresh  = std::stod(val);
        else if (key == "FIXED_ALPHA")     cfg.fixed_alpha       = std::stod(val);
        else if (key == "FIXED_BETA")      cfg.fixed_beta        = std::stod(val);
        else if (key == "FIXED_RHO")       cfg.fixed_rho         = std::stod(val);
        else if (key == "VEHICLE_TYPES_FILE") cfg.vehicle_types_file = val;
    }
    return cfg;
}

// =============================================================================
//  SECTION 3 -- CSV Map Loader
// =============================================================================

std::vector<Edge> load_map(const std::string& path, int& num_nodes) {
    std::vector<Edge> edges;
    std::ifstream f(path);
    if (!f.is_open()) {
        std::cerr << "[ERROR] Cannot open map file: " << path << "\n";
        std::exit(1);
    }

    std::string line;
    std::getline(f, line); // skip header
    int max_node = -1;

    while (std::getline(f, line)) {
        line = trim(line);
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string tok;

        Edge e;
        std::getline(ss, tok, ','); e.from      = std::stoi(tok);
        std::getline(ss, tok, ','); e.to        = std::stoi(tok);
        std::getline(ss, tok, ','); e.length    = std::stod(tok);
        std::getline(ss, tok, ','); e.lanes     = std::stoi(tok);
        std::getline(ss, tok, ','); e.road_width= std::stod(tok);
        std::getline(ss, tok, ','); e.f_current = std::stod(tok);
        std::getline(ss, tok, ','); e.f_in      = std::stod(tok);
        std::getline(ss, tok, ','); e.f_out     = std::stod(tok);

        max_node = std::max(max_node, std::max(e.from, e.to));
        edges.push_back(e);
    }

    num_nodes = max_node + 1;
    return edges;
}

// =============================================================================
//  SECTION 3b -- S-D Pairs Loader
// =============================================================================

struct SDPair {
    int src, dst;
    std::string vehicle_type;
};

std::vector<SDPair> load_sd_pairs(const std::string& path) {
    std::vector<SDPair> pairs;
    std::ifstream f(path);
    if (!f.is_open()) {
        std::cerr << "[ERROR] Cannot open pairs file: " << path << "\n";
        std::exit(1);
    }

    std::string line;
    std::getline(f, line); // skip header
    while (std::getline(f, line)) {
        line = trim(line);
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string tok;
        SDPair p;
        std::getline(ss, tok, ','); p.src = std::stoi(trim(tok));
        std::getline(ss, tok, ','); p.dst = std::stoi(trim(tok));
        if (std::getline(ss, tok, ',')) {
            p.vehicle_type = trim(tok);
        } else {
            p.vehicle_type = "privatecar"; // default
        }
        pairs.push_back(p);
    }
    return pairs;
}

// =============================================================================
//  SECTION 4 -- Road Condition Factor (Paper Section IV-B)
// =============================================================================

/*
 * Congestion coefficient  (formula 8):
 *   Ci(t) = (fi(t-1) + fin_i(t) - fout_i(t)) * L  /  (li * di)
 *           if numerator > 0, else 0
 *
 * Road condition factor   (formula 10):
 *   Ri(t) = di * (1 + Ci(t))
 */
double congestion_coeff(const Edge& e, double L) {
    double net = e.f_current + e.f_in - e.f_out;
    if (net <= 0.0) return 0.0;
    return (net * L) / (static_cast<double>(e.lanes) * e.length);
}

double road_condition_factor(const Edge& e, double L) {
    return e.length * (1.0 + congestion_coeff(e, L));
}

// Build adjacency lookup: adj[from][to] = edge index
std::vector<std::map<int,int>> build_adjacency(
        const std::vector<Edge>& edges, int n)
{
    std::vector<std::map<int,int>> adj(n);
    for (int i = 0; i < (int)edges.size(); ++i)
        adj[edges[i].from][edges[i].to] = i;
    return adj;
}

// =============================================================================
//  SECTION 4b -- Vehicle Types Loader & Constraint Check
// =============================================================================

std::map<std::string, VehicleType> load_vehicle_types(const std::string& path) {
    std::map<std::string, VehicleType> vtypes;
    std::ifstream f(path);
    if (!f.is_open()) {
        std::cerr << "[WARN] Cannot open vehicle types file: " << path
                  << " -- using default privatecar only.\n";
        VehicleType def;
        def.name = "privatecar"; def.width = 1.8; def.height = 1.5;
        def.length = 4.5; def.min_lanes_required = 1; def.min_road_width = 3.5;
        vtypes["privatecar"] = def;
        return vtypes;
    }

    std::string line;
    std::getline(f, line); // skip header
    while (std::getline(f, line)) {
        line = trim(line);
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string tok;
        VehicleType vt;
        std::getline(ss, tok, ','); vt.name               = trim(tok);
        std::getline(ss, tok, ','); vt.width              = std::stod(tok);
        std::getline(ss, tok, ','); vt.height             = std::stod(tok);
        std::getline(ss, tok, ','); vt.length             = std::stod(tok);
        std::getline(ss, tok, ','); vt.min_lanes_required = std::stoi(tok);
        std::getline(ss, tok, ','); vt.min_road_width     = std::stod(tok);
        vtypes[vt.name] = vt;
    }
    return vtypes;
}

/// Check if a given vehicle type can physically use an edge.
/// Returns true if the edge's road is wide enough and has enough lanes.
bool can_vehicle_use_edge(const Edge& e, const VehicleType& vt) {
    if (e.lanes < vt.min_lanes_required) return false;
    if (e.road_width < vt.min_road_width) return false;
    return true;
}

// =============================================================================
//  SECTION 5 -- Random Utilities
// =============================================================================

static double rand01() {
    return static_cast<double>(rand()) / RAND_MAX;
}

static double rand_range(double lo, double hi) {
    return lo + rand01() * (hi - lo);
}

// =============================================================================
//  SECTION 6 -- ACO (Point-to-Point, Road Condition Factor)
// =============================================================================

struct ACOResult {
    std::vector<int> path;    // sequence of node IDs
    double           cost;    // sum of R values along path
    bool             found;
};

/*
 * Transfer probability (formula 1, adapted for point-to-point):
 *
 *   p_k_ij = [tau_ij]^alpha * [eta_ij]^beta  /  SUM_{s in allowed} [tau_is]^alpha * [eta_is]^beta
 *
 * where eta_ij = 1 / R_ij   (heuristic -- prefer low congestion roads)
 *
 * Ants stop as soon as they reach END_NODE (not when all nodes visited).
 */
ACOResult run_aco(
    const std::vector<Edge>&            edges,
    const std::vector<std::map<int,int>>& adj,
    int    n,
    int    start, int end,
    double alpha, double beta, double rho,
    double Q_const, double tau_init,
    int    num_ants, int max_iter,
    double L,
    const VehicleType* vt = nullptr)  // vehicle constraint (nullptr = no constraint)
{
    // Pheromone matrix  tau[i][j] -- using same map structure as adj
    // Stored as n x n dense for simplicity (n <= 100 expected)
    std::vector<std::vector<double>> tau(n, std::vector<double>(n, tau_init));

    ACOResult best;
    best.found = false;
    best.cost  = std::numeric_limits<double>::infinity();

    for (int iter = 0; iter < max_iter; ++iter) {

        // Pheromone increment buffer
        std::vector<std::vector<double>> delta_tau(
                n, std::vector<double>(n, 0.0));

        for (int ant = 0; ant < num_ants; ++ant) {
            // -- Ant walk from start -> end --
            std::vector<int> path;
            std::vector<bool> visited(n, false);
            path.push_back(start);
            visited[start] = true;
            int cur = start;
            double cost = 0.0;
            bool reached = false;

            // Safety: at most n*2 steps to avoid infinite loop
            for (int step = 0; step < n * 2 && !reached; ++step) {
                // Collect candidates reachable from cur
                std::vector<int> candidates;
                for (auto it = adj[cur].begin(); it != adj[cur].end(); ++it) {
                    int nb = it->first;
                    if (!visited[nb]) {
                        // Vehicle type constraint: skip if edge is too narrow
                        if (vt != nullptr) {
                            int eidx_check = it->second;
                            if (!can_vehicle_use_edge(edges[eidx_check], *vt))
                                continue;
                        }
                        candidates.push_back(nb);
                    }
                }
                // If end_node is directly reachable, add even if "visited"
                // (allows direct hop to destination)
                if (!visited[end] && adj[cur].count(end))
                    ; // already in candidates if not visited

                // Allow going to end even if it's in visited
                bool end_direct = adj[cur].count(end) > 0;
                // But also check vehicle constraint for the end edge
                if (end_direct && vt != nullptr) {
                    int end_eidx = adj[cur].at(end);
                    if (!can_vehicle_use_edge(edges[end_eidx], *vt))
                        end_direct = false;
                }

                if (candidates.empty() && !end_direct) break; // stuck

                // Build probability distribution
                std::vector<double> probs;
                std::vector<int>    choices;

                auto add_candidate = [&](int nb) {
                    int eidx = adj[cur].at(nb);
                    double R = road_condition_factor(edges[eidx], L);
                    double eta = (R > 1e-9) ? 1.0 / R : 1e9;
                    double val = std::pow(tau[cur][nb], alpha)
                               * std::pow(eta,          beta);
                    probs.push_back(val);
                    choices.push_back(nb);
                };

                // Always include end_node if directly reachable
                bool end_added = false;
                if (end_direct && !visited[end]) {
                    // will be included via candidates
                }
                if (end_direct && adj[cur].count(end)) {
                    // Force-add end as choice even if visited
                    bool already = false;
                    for (int c : candidates)
                        if (c == end) { already = true; break; }
                    if (!already) {
                        candidates.push_back(end);
                        end_added = true;
                    }
                }

                for (int nb : candidates) add_candidate(nb);

                if (choices.empty()) break;

                // Roulette-wheel selection
                double total = 0.0;
                for (double p : probs) total += p;
                double r = rand01() * total;
                double cumul = 0.0;
                int chosen = choices.back();
                for (size_t k = 0; k < choices.size(); ++k) {
                    cumul += probs[k];
                    if (cumul >= r) { chosen = choices[k]; break; }
                }

                int eidx = adj[cur].at(chosen);
                cost += road_condition_factor(edges[eidx], L);
                path.push_back(chosen);
                visited[chosen] = true;
                cur = chosen;

                if (cur == end) { reached = true; }
            }

            if (!reached) continue;

            // -- Pheromone deposit (formula 5) --
            double deposit = Q_const / cost;
            for (size_t k = 0; k + 1 < path.size(); ++k) {
                delta_tau[path[k]][path[k+1]] += deposit;
            }

            if (cost < best.cost) {
                best.cost  = cost;
                best.path  = path;
                best.found = true;
            }
        } // end ants

        // -- Global pheromone evaporation (formula 3) --
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < n; ++j)
                tau[i][j] = (1.0 - rho) * tau[i][j] + delta_tau[i][j];

    } // end iterations

    return best;
}

// =============================================================================
//  SECTION 7 -- PSO  (tunes alpha, beta, rho for ACO)
// =============================================================================

struct Particle {
    double alpha, beta, rho;
    double v_alpha, v_beta, v_rho;
    double p_alpha, p_beta, p_rho;   // personal best position
    double p_cost;                    // personal best cost
};

struct PSOResult {
    double alpha, beta, rho;
    double best_cost;
};

/*
 * PSO fitness: run ACO with given (alpha, beta, rho) and return best path cost.
 * Lower cost = better.
 * Using formula 6 for velocity update, formula 7 for position update.
 */
PSOResult run_pso(
    const std::vector<Edge>&            edges,
    const std::vector<std::map<int,int>>& adj,
    int n, int start, int end,
    const Config& cfg,
    const VehicleType* vt = nullptr)
{
    std::vector<Particle> swarm(cfg.pso_swarm);

    // Initialise particles randomly within bounds
    for (auto& p : swarm) {
        p.alpha   = rand_range(cfg.alpha_min, cfg.alpha_max);
        p.beta    = rand_range(cfg.beta_min,  cfg.beta_max);
        p.rho     = rand_range(cfg.rho_min,   cfg.rho_max);
        p.v_alpha = rand_range(-0.1, 0.1);
        p.v_beta  = rand_range(-0.1, 0.1);
        p.v_rho   = rand_range(-0.05, 0.05);
        p.p_alpha = p.alpha;
        p.p_beta  = p.beta;
        p.p_rho   = p.rho;
        p.p_cost  = std::numeric_limits<double>::infinity();
    }

    // Global best
    double g_alpha = swarm[0].alpha;
    double g_beta  = swarm[0].beta;
    double g_rho   = swarm[0].rho;
    double g_cost  = std::numeric_limits<double>::infinity();

    auto clamp = [](double v, double lo, double hi) {
        return std::max(lo, std::min(hi, v));
    };

    std::cout << "\n[PSO] Tuning ACO parameters over "
              << cfg.pso_iter << " iterations ...\n";

    for (int iter = 0; iter < cfg.pso_iter; ++iter) {
        for (auto& p : swarm) {
            // Evaluate fitness
            ACOResult res = run_aco(
                edges, adj, n, start, end,
                p.alpha, p.beta, p.rho,
                cfg.Q_const, cfg.tau_init,
                cfg.num_ants,
                std::max(10, cfg.aco_iter / 5),   // shorter eval run
                cfg.avg_vehicle_len, vt);

            double cost = res.found
                        ? res.cost
                        : std::numeric_limits<double>::infinity();

            // Personal best update
            if (cost < p.p_cost) {
                p.p_cost  = cost;
                p.p_alpha = p.alpha;
                p.p_beta  = p.beta;
                p.p_rho   = p.rho;
            }
            // Global best update
            if (cost < g_cost) {
                g_cost  = cost;
                g_alpha = p.alpha;
                g_beta  = p.beta;
                g_rho   = p.rho;
            }

            // Velocity & position update (formulas 6-7)
            double r1 = rand01(), r2 = rand01();
            p.v_alpha = cfg.pso_w * p.v_alpha
                      + cfg.pso_c1 * r1 * (p.p_alpha - p.alpha)
                      + cfg.pso_c2 * r2 * (g_alpha   - p.alpha);
            p.v_beta  = cfg.pso_w * p.v_beta
                      + cfg.pso_c1 * r1 * (p.p_beta  - p.beta)
                      + cfg.pso_c2 * r2 * (g_beta    - p.beta);
            p.v_rho   = cfg.pso_w * p.v_rho
                      + cfg.pso_c1 * r1 * (p.p_rho   - p.rho)
                      + cfg.pso_c2 * r2 * (g_rho     - p.rho);

            p.alpha = clamp(p.alpha + p.v_alpha, cfg.alpha_min, cfg.alpha_max);
            p.beta  = clamp(p.beta  + p.v_beta,  cfg.beta_min,  cfg.beta_max);
            p.rho   = clamp(p.rho   + p.v_rho,   cfg.rho_min,   cfg.rho_max);
        }

        // Progress every 25 iterations
        if ((iter + 1) % 25 == 0 || iter == 0) {
            std::cout << "  iter " << std::setw(4) << (iter+1)
                      << "  |  best_cost = "
                      << std::fixed << std::setprecision(2) << g_cost
                      << "  alpha=" << std::setprecision(3) << g_alpha
                      << "  beta=" << g_beta
                      << "  rho=" << g_rho << "\n";
        }
    }

    return { g_alpha, g_beta, g_rho, g_cost };
}

// =============================================================================
//  SECTION 8 -- Traffic Simulation (update fi per step)
// =============================================================================

void update_traffic(std::vector<Edge>& edges, double noise) {
    for (auto& e : edges) {
        // Vehicles now on road = previous + in - out
        double net = e.f_current + e.f_in - e.f_out;
        e.f_current = std::max(0.0, net);

        // Randomly vary in/out flows with +/- noise
        double perturb_in  = 1.0 + rand_range(-noise, noise);
        double perturb_out = 1.0 + rand_range(-noise, noise);
        e.f_in  = std::max(0.0, e.f_in  * perturb_in);
        e.f_out = std::max(0.0, e.f_out * perturb_out);
    }
}

// =============================================================================
//  SECTION 9 -- Helpers: printing
// =============================================================================

void print_path(const std::vector<int>& path, double cost,
                const std::string& label)
{
    std::cout << "  " << label << " | cost="
              << std::fixed << std::setprecision(2) << cost
              << "  path: ";
    for (size_t i = 0; i < path.size(); ++i) {
        std::cout << path[i];
        if (i + 1 < path.size()) std::cout << " -> ";
    }
    std::cout << "\n";
}

std::string path_to_string(const std::vector<int>& path) {
    std::string s;
    for (size_t i = 0; i < path.size(); ++i) {
        s += std::to_string(path[i]);
        if (i + 1 < path.size()) s += "->";
    }
    return s;
}

std::string path_to_csv_string(const std::vector<int>& path) {
    std::string s;
    for (size_t i = 0; i < path.size(); ++i) {
        s += std::to_string(path[i]);
        if (i + 1 < path.size()) s += "-";
    }
    return s;
}

void print_banner(const std::string& msg) {
    std::string bar(60, '=');
    std::cout << "\n" << bar << "\n  " << msg << "\n" << bar << "\n";
}

double path_cost_from(
    const std::vector<int>& path, int from_node,
    const std::vector<Edge>& edges,
    const std::vector<std::map<int,int>>& adj, double L)
{
    double cost = 0.0;
    bool counting = false;
    for (size_t i = 0; i + 1 < path.size(); ++i) {
        if (path[i] == from_node) counting = true;
        if (counting && adj[path[i]].count(path[i+1])) {
            int eidx = adj[path[i]].at(path[i+1]);
            cost += road_condition_factor(edges[eidx], L);
        }
    }
    return cost;
}

// =============================================================================
//  SECTION 10 -- Run Single Source-Destination Pair
//  (Preserves the EXACT flowchart: PSO -> ACO -> Dynamic Re-planning)
// =============================================================================

PairResult run_single_pair(
    std::vector<Edge> edges,                // BY VALUE: fresh traffic per pair
    const std::vector<std::map<int,int>>& adj,
    int n, int src, int dst,
    const Config& cfg,
    std::ofstream& reroute_log,
    int pair_index,
    const VehicleType* vt = nullptr)
{
    PairResult result;
    result.source      = src;
    result.destination = dst;
    result.replan_count = 0;
    result.reached     = false;
    result.edges_blocked = 0;
    result.vehicle_type = vt ? vt->name : "default";

    // Use vehicle-specific length if available, else default
    double veh_len = vt ? vt->length : cfg.avg_vehicle_len;

    // =========================================================================
    //  PHASE 1 -- PSO: optimise alpha, beta, rho
    //  (Flowchart: "PHASE 1 -- PSO optimization (one-time)")
    // =========================================================================
    std::cout << "\n  --- PHASE 1: PSO Parameter Optimisation ---\n";

    PSOResult pso = run_pso(edges, adj, n, src, dst, cfg, vt);

    result.pso_alpha = pso.alpha;
    result.pso_beta  = pso.beta;
    result.pso_rho   = pso.rho;

    std::cout << "\n  [PSO] Optimal ACO parameters found:\n"
              << "        alpha = " << std::fixed << std::setprecision(4) << pso.alpha << "\n"
              << "        beta  = " << pso.beta  << "\n"
              << "        rho   = " << pso.rho   << "\n"
              << "        best_cost = " << pso.best_cost << "\n";

    // =========================================================================
    //  PHASE 2 -- Initial ACO path (besttour)
    //  (Flowchart: "PHASE 2 -- Initial pathfinding")
    // =========================================================================
    std::cout << "\n  --- PHASE 2: Initial ACO Path Planning ---\n";

    ACOResult initial = run_aco(
        edges, adj, n,
        src, dst,
        pso.alpha, pso.beta, pso.rho,
        cfg.Q_const, cfg.tau_init,
        cfg.num_ants, cfg.aco_iter,
        veh_len, vt);

    if (!initial.found) {
        std::cerr << "  [WARN] ACO could not find any path from "
                  << src << " to " << dst << ".\n"
                  << "         Check map connectivity.\n";
        result.initial_cost = 0;
        result.final_cost   = 0;
        return result;
    }

    result.initial_path = initial.path;
    result.initial_cost = initial.cost;

    std::cout << "\n  [ACO] Initial best path found:\n";
    print_path(initial.path, initial.cost, "besttour");

    // =========================================================================
    //  PHASE 3 -- Dynamic Re-planning Loop
    //  (Flowchart: "Dynamic monitoring" -> "Trigger condition?" -> etc.)
    // =========================================================================
    std::cout << "\n  --- PHASE 3: Dynamic Simulation & Re-planning ---\n";

    std::vector<int> best_path = initial.path;
    double           best_cost = initial.cost;
    double           ar        = 0.0;    // traversed cost so far
    int              cur_node  = src;

    std::cout << "  Simulating " << cfg.sim_steps << " time steps ...\n\n";

    for (int step = 0; step < cfg.sim_steps && cur_node != dst; ++step) {

        // -- Advance one edge along best_path --
        // Find cur_node's position in path
        int pos = -1;
        for (int i = 0; i < (int)best_path.size(); ++i)
            if (best_path[i] == cur_node) { pos = i; break; }

        if (pos < 0 || pos + 1 >= (int)best_path.size()) {
            std::cout << "  [STEP " << step << "] Reached end or lost position.\n";
            break;
        }

        int next_node = best_path[pos + 1];
        int eidx      = -1;
        if (adj[cur_node].count(next_node))
            eidx = adj[cur_node].at(next_node);

        double R_prev = (eidx >= 0)
                       ? road_condition_factor(edges[eidx], cfg.avg_vehicle_len)
                       : 0.0;

        // -- Traffic update (simulate t -> t+1) --
        // (Flowchart: "Dynamic monitoring (t -> t+1)")
        update_traffic(edges, cfg.traffic_noise);
        std::vector<double> R_new(edges.size());
        for (int i = 0; i < (int)edges.size(); ++i)
            R_new[i] = road_condition_factor(edges[i], cfg.avg_vehicle_len);

        // -- Traverse the segment --
        double R_cur = (eidx >= 0) ? R_new[eidx] : 0.0;
        double delta_R = std::fabs(R_cur - R_prev);

        ar       += R_cur;
        cur_node  = next_node;

        std::cout << "  [STEP " << std::setw(2) << step << "] "
                  << "node=" << std::setw(2) << cur_node
                  << "  R=" << std::fixed << std::setprecision(2) << R_cur
                  << "  dR=" << delta_R
                  << "  ar=" << ar;

        // -- Trigger check (formula 11 / flowchart) --
        // (Flowchart: "Trigger condition? (dR_i > dR_max) OR (R_i(t) > R_max)")
        bool trigger = (delta_R > cfg.delta_R_max) || (R_cur > cfg.R_max);

        if (trigger && cur_node != dst) {
            std::cout << "  <- TRIGGER";

            // Re-plan from current node
            // (Flowchart: "YES: Re-plan from current node using improved ACO")
            ACOResult replan = run_aco(
                edges, adj, n,
                cur_node, dst,
                pso.alpha, pso.beta, pso.rho,
                cfg.Q_const, cfg.tau_init,
                cfg.num_ants, cfg.aco_iter,
                veh_len, vt);

            if (replan.found) {
                // Compare: newtour < besttour - ar  (step 7)
                // (Flowchart: "Is newtour better? newtour < (besttour - a_r)")
                double remaining_old = path_cost_from(best_path, cur_node, edges, adj, cfg.avg_vehicle_len);
                if (replan.cost < remaining_old) {
                    std::cout << "  -> REROUTE"
                              << " (new=" << replan.cost
                              << " < rem=" << remaining_old << ")";

                    // Accept new plan
                    // (Flowchart: "YES update: besttour <- newtour + a_r")
                    best_path = replan.path;
                    best_cost = replan.cost + ar;
                    cur_node  = replan.path[0];
                    ++result.replan_count;

                    // Log
                    reroute_log << pair_index << "," << src << "," << dst << ","
                                << step << "," << cur_node << ",REROUTE,"
                                << std::fixed << std::setprecision(2)
                                << best_cost << "," << ar << ","
                                << path_to_csv_string(best_path) << "\n";
                } else {
                    std::cout << "  -> keep existing (new="
                              << replan.cost << " >= rem=" << remaining_old << ")";
                    reroute_log << pair_index << "," << src << "," << dst << ","
                                << step << "," << cur_node << ",TRIGGER_KEPT,"
                                << std::fixed << std::setprecision(2)
                                << best_cost << "," << ar << ","
                                << path_to_csv_string(best_path) << "\n";
                }
            } else {
                std::cout << "  -> no new path found";
                reroute_log << pair_index << "," << src << "," << dst << ","
                            << step << "," << cur_node << ",TRIGGER_NOREPLAN,"
                            << std::fixed << std::setprecision(2)
                            << best_cost << "," << ar << ","
                            << path_to_csv_string(best_path) << "\n";
            }
        } else {
            reroute_log << pair_index << "," << src << "," << dst << ","
                        << step << "," << cur_node << ",OK,"
                        << std::fixed << std::setprecision(2)
                        << best_cost << "," << ar << ","
                        << path_to_csv_string(best_path) << "\n";
        }

        std::cout << "\n";

        if (cur_node == dst) {
            std::cout << "\n  [OK] Destination " << dst
                      << " reached at step " << step << "!\n";
            break;
        }
    }

    result.final_path = best_path;
    result.final_cost = ar;
    result.reached    = (cur_node == dst);

    return result;
}

// =============================================================================
//  SECTION 10a -- Run ACO + Dynamic Re-planning with GIVEN alpha, beta, rho
//  No PSO -- directly uses the provided parameter values.
//  Used for both PSO-tuned runs and fixed-parameter runs.
// =============================================================================

PairResult run_aco_dynamic_only(
    std::vector<Edge> edges,                // BY VALUE: fresh traffic per pair
    const std::vector<std::map<int,int>>& adj,
    int n, int src, int dst,
    double use_alpha, double use_beta, double use_rho,
    const Config& cfg,
    std::ofstream& reroute_log,
    int pair_index,
    const std::string& label,
    const VehicleType* vt = nullptr)
{
    PairResult result;
    result.source      = src;
    result.destination = dst;
    result.replan_count = 0;
    result.reached     = false;
    result.edges_blocked = 0;
    result.vehicle_type = vt ? vt->name : "default";

    // Use vehicle-specific length if available, else default
    double veh_len = vt ? vt->length : cfg.avg_vehicle_len;

    result.pso_alpha = use_alpha;
    result.pso_beta  = use_beta;
    result.pso_rho   = use_rho;

    std::cout << "\n  [" << label << "] Using ACO parameters:\n"
              << "        alpha = " << std::fixed << std::setprecision(4) << use_alpha << "\n"
              << "        beta  = " << use_beta  << "\n"
              << "        rho   = " << use_rho   << "\n";

    // =========================================================================
    //  PHASE 2 -- Initial ACO path (besttour)
    // =========================================================================
    std::cout << "\n  --- PHASE 2: Initial ACO Path Planning (" << label << ") ---\n";

    ACOResult initial = run_aco(
        edges, adj, n,
        src, dst,
        use_alpha, use_beta, use_rho,
        cfg.Q_const, cfg.tau_init,
        cfg.num_ants, cfg.aco_iter,
        veh_len, vt);

    if (!initial.found) {
        std::cerr << "  [WARN] ACO could not find any path from "
                  << src << " to " << dst << ".\n"
                  << "         Check map connectivity.\n";
        result.initial_cost = 0;
        result.final_cost   = 0;
        return result;
    }

    result.initial_path = initial.path;
    result.initial_cost = initial.cost;

    std::cout << "\n  [ACO] Initial best path found:\n";
    print_path(initial.path, initial.cost, "besttour");

    // =========================================================================
    //  PHASE 3 -- Dynamic Re-planning Loop (same as PSO version)
    // =========================================================================
    std::cout << "\n  --- PHASE 3: Dynamic Simulation & Re-planning (" << label << ") ---\n";

    std::vector<int> best_path = initial.path;
    double           best_cost = initial.cost;
    double           ar        = 0.0;
    int              cur_node  = src;

    std::cout << "  Simulating " << cfg.sim_steps << " time steps ...\n\n";

    for (int step = 0; step < cfg.sim_steps && cur_node != dst; ++step) {

        int pos = -1;
        for (int i = 0; i < (int)best_path.size(); ++i)
            if (best_path[i] == cur_node) { pos = i; break; }

        if (pos < 0 || pos + 1 >= (int)best_path.size()) {
            std::cout << "  [STEP " << step << "] Reached end or lost position.\n";
            break;
        }

        int next_node = best_path[pos + 1];
        int eidx      = -1;
        if (adj[cur_node].count(next_node))
            eidx = adj[cur_node].at(next_node);

        double R_prev = (eidx >= 0)
                       ? road_condition_factor(edges[eidx], cfg.avg_vehicle_len)
                       : 0.0;

        update_traffic(edges, cfg.traffic_noise);
        std::vector<double> R_new(edges.size());
        for (int i = 0; i < (int)edges.size(); ++i)
            R_new[i] = road_condition_factor(edges[i], cfg.avg_vehicle_len);

        double R_cur = (eidx >= 0) ? R_new[eidx] : 0.0;
        double delta_R = std::fabs(R_cur - R_prev);

        ar       += R_cur;
        cur_node  = next_node;

        std::cout << "  [STEP " << std::setw(2) << step << "] "
                  << "node=" << std::setw(2) << cur_node
                  << "  R=" << std::fixed << std::setprecision(2) << R_cur
                  << "  dR=" << delta_R
                  << "  ar=" << ar;

        bool trigger = (delta_R > cfg.delta_R_max) || (R_cur > cfg.R_max);

        if (trigger && cur_node != dst) {
            std::cout << "  <- TRIGGER";

            ACOResult replan = run_aco(
                edges, adj, n,
                cur_node, dst,
                use_alpha, use_beta, use_rho,
                cfg.Q_const, cfg.tau_init,
                cfg.num_ants, cfg.aco_iter,
                veh_len, vt);

            if (replan.found) {
                double remaining_old = path_cost_from(best_path, cur_node, edges, adj, cfg.avg_vehicle_len);
                if (replan.cost < remaining_old) {
                    std::cout << "  -> REROUTE"
                              << " (new=" << replan.cost
                              << " < rem=" << remaining_old << ")";
                    best_path = replan.path;
                    best_cost = replan.cost + ar;
                    cur_node  = replan.path[0];
                    ++result.replan_count;

                    reroute_log << pair_index << "," << src << "," << dst << ","
                                << step << "," << cur_node << ",REROUTE,"
                                << std::fixed << std::setprecision(2)
                                << best_cost << "," << ar << ","
                                << path_to_csv_string(best_path) << "\n";
                } else {
                    std::cout << "  -> keep existing (new="
                              << replan.cost << " >= rem=" << remaining_old << ")";
                    reroute_log << pair_index << "," << src << "," << dst << ","
                                << step << "," << cur_node << ",TRIGGER_KEPT,"
                                << std::fixed << std::setprecision(2)
                                << best_cost << "," << ar << ","
                                << path_to_csv_string(best_path) << "\n";
                }
            } else {
                std::cout << "  -> no new path found";
                reroute_log << pair_index << "," << src << "," << dst << ","
                            << step << "," << cur_node << ",TRIGGER_NOREPLAN,"
                            << std::fixed << std::setprecision(2)
                            << best_cost << "," << ar << ","
                            << path_to_csv_string(best_path) << "\n";
            }
        } else {
            reroute_log << pair_index << "," << src << "," << dst << ","
                        << step << "," << cur_node << ",OK,"
                        << std::fixed << std::setprecision(2)
                        << best_cost << "," << ar << ","
                        << path_to_csv_string(best_path) << "\n";
        }

        std::cout << "\n";

        if (cur_node == dst) {
            std::cout << "\n  [OK] Destination " << dst
                      << " reached at step " << step << "!\n";
            break;
        }
    }

    result.final_path = best_path;
    result.final_cost = ar;
    result.reached    = (cur_node == dst);

    return result;
}

// =============================================================================
//  SECTION 10b -- Combined Route Optimization (Iterative)
//  Outer loop: accumulate traffic from shared edges, re-run until stable.
//  Inner loop: run each S-D pair using the EXACT flowchart (PSO->ACO->Replan).
// =============================================================================

struct CombinedIterResult {
    int    iteration;
    double avg_cost;
    double cost_change_pct;   // vs previous iteration
    int    total_reroutes;
    int    route_changes;     // how many pairs changed their final path
};

/// Apply aggregate traffic from route results onto the edge set.
/// For each edge used by N routes, increase f_current by weight * N.
void apply_aggregate_traffic(
    std::vector<Edge>& edges,
    const std::vector<std::map<int,int>>& adj,
    const std::vector<PairResult>& results,
    double weight)
{
    // Count edge usage
    std::map<std::pair<int,int>, int> edge_freq;
    for (const auto& r : results) {
        if (!r.reached) continue;
        const auto& path = r.final_path;
        for (size_t k = 0; k + 1 < path.size(); ++k)
            edge_freq[{path[k], path[k+1]}]++;
    }

    // Apply: for each used edge, add weight * freq to f_current and f_in
    for (auto& e : edges) {
        auto key = std::make_pair(e.from, e.to);
        auto it = edge_freq.find(key);
        if (it != edge_freq.end() && it->second >= 2) {
            // Only penalise edges shared by 2+ routes
            double penalty = weight * (it->second - 1);
            e.f_current += penalty * (e.lanes * e.length / 5.0) * 0.1;
            e.f_in      += penalty * 2.0;
        }
    }
}

std::pair<std::vector<PairResult>, std::vector<CombinedIterResult>>
run_combined_optimization(
    const std::vector<Edge>& original_edges,
    const std::vector<std::map<int,int>>& adj,
    int n,
    const std::vector<SDPair>& sd_pairs,
    const Config& cfg,
    const std::map<std::string, VehicleType>& vehicle_types)
{
    std::vector<CombinedIterResult> history;
    std::vector<PairResult> best_results;
    std::vector<PairResult> prev_results;
    double prev_avg_cost = 0.0;

    // Open a combined reroute log
    std::ofstream combined_rlog("reroute_log_combined.txt");
    combined_rlog << "combined_iter,pair_id,source,destination,step,cur_node,"
                  << "event,best_cost,ar,path\n";

    for (int citer = 0; citer < cfg.combined_iters; ++citer) {
        print_banner("COMBINED ITERATION " + std::to_string(citer + 1)
                     + " / " + std::to_string(cfg.combined_iters));

        // Build traffic-adjusted edges for this iteration
        std::vector<Edge> iter_edges = original_edges;
        if (citer > 0 && !prev_results.empty()) {
            // Accumulate traffic from previous iteration's routes
            apply_aggregate_traffic(iter_edges, adj, prev_results, cfg.combined_weight);
            std::cout << "  [COMBINED] Applied aggregate traffic from iteration "
                      << citer << " (weight=" << cfg.combined_weight << ")\n";
        }

        // Run all S-D pairs with the adjusted traffic
        std::vector<PairResult> iter_results;
        for (int i = 0; i < (int)sd_pairs.size(); ++i) {
            int src = sd_pairs[i].src;
            int dst = sd_pairs[i].dst;
            const VehicleType* vt_ptr = nullptr;
            auto vt_it = vehicle_types.find(sd_pairs[i].vehicle_type);
            if (vt_it != vehicle_types.end()) vt_ptr = &vt_it->second;

            std::string pair_label = "COMB-ITER " + std::to_string(citer+1)
                                   + "  PAIR " + std::to_string(i)
                                   + " (" + std::to_string(src)
                                   + " -> " + std::to_string(dst) + ")";
            print_banner(pair_label);

            // Wrap reroute log to prefix combined iteration
            std::ofstream pair_rlog("reroute_log.txt", std::ios::app);

            PairResult result = run_single_pair(
                iter_edges, adj, n, src, dst, cfg, pair_rlog, i, vt_ptr);

            pair_rlog.close();

            iter_results.push_back(result);

            std::cout << "\n  Pair " << i << " " << src << "->" << dst
                      << " cost=" << std::fixed << std::setprecision(2)
                      << result.final_cost
                      << " reached=" << (result.reached ? "YES" : "NO") << "\n";
        }

        // Compute iteration statistics
        double total_cost = 0.0;
        int    successful = 0;
        int    total_reroutes = 0;
        int    route_changes = 0;

        for (int i = 0; i < (int)iter_results.size(); ++i) {
            const auto& r = iter_results[i];
            if (r.reached) {
                total_cost += r.final_cost;
                successful++;
            }
            total_reroutes += r.replan_count;

            // Check if route changed from previous iteration
            if (citer > 0 && i < (int)prev_results.size()) {
                if (iter_results[i].final_path != prev_results[i].final_path)
                    route_changes++;
            }
        }

        double avg_cost = (successful > 0) ? total_cost / successful : 0.0;
        double change_pct = (citer > 0 && prev_avg_cost > 0)
                          ? std::fabs(avg_cost - prev_avg_cost) / prev_avg_cost
                          : 1.0;

        CombinedIterResult cir;
        cir.iteration      = citer + 1;
        cir.avg_cost        = avg_cost;
        cir.cost_change_pct = change_pct;
        cir.total_reroutes  = total_reroutes;
        cir.route_changes   = (citer > 0) ? route_changes : (int)sd_pairs.size();
        history.push_back(cir);

        std::cout << "\n  [COMBINED ITER " << citer+1 << "] avg_cost="
                  << std::fixed << std::setprecision(2) << avg_cost
                  << "  change=" << std::setprecision(2) << (change_pct*100) << "%"
                  << "  route_changes=" << route_changes
                  << "  reroutes=" << total_reroutes << "\n";

        prev_results  = iter_results;
        best_results  = iter_results;
        prev_avg_cost = avg_cost;

        // Stabilization check
        if (citer > 0 && change_pct < cfg.stability_thresh) {
            std::cout << "\n  ** STABILIZED at iteration " << citer+1
                      << " (change " << std::setprecision(2) << (change_pct*100)
                      << "% < threshold " << (cfg.stability_thresh*100) << "%) **\n";
            break;
        }
    }

    combined_rlog.close();
    return {best_results, history};
}

// =============================================================================
//  SECTION 11 -- Save All-Pairs Results to CSV
// =============================================================================

void save_results(const std::vector<PairResult>& results,
                  const std::string& filename)
{
    std::ofstream f(filename);
    f << "pair_id,source,destination,vehicle_type,initial_path,initial_cost,"
      << "final_path,final_cost,reroutes,reached,"
      << "pso_alpha,pso_beta,pso_rho\n";

    for (int i = 0; i < (int)results.size(); ++i) {
        const auto& r = results[i];
        f << i << ","
          << r.source << "," << r.destination << ","
          << r.vehicle_type << ","
          << path_to_csv_string(r.initial_path) << ","
          << std::fixed << std::setprecision(2) << r.initial_cost << ","
          << path_to_csv_string(r.final_path) << ","
          << r.final_cost << ","
          << r.replan_count << ","
          << (r.reached ? "YES" : "NO") << ","
          << std::setprecision(4) << r.pso_alpha << ","
          << r.pso_beta << "," << r.pso_rho << "\n";
    }
    f.close();
    std::cout << "\n  Results saved -> " << filename << "\n";
}

// =============================================================================
//  SECTION 12 -- Network-Level Analysis (Combined Route Optimization)
// =============================================================================

void analyze_network(const std::vector<PairResult>& results,
                     const std::vector<Edge>& edges,
                     int n,
                     const std::string& filename)
{
    std::ofstream f(filename);

    f << "================================================================\n"
      << "  NETWORK-LEVEL ANALYSIS (Combined Route Optimization)\n"
      << "================================================================\n\n";

    // --- Edge usage frequency ---
    std::map<std::pair<int,int>, int> edge_freq;
    std::map<std::pair<int,int>, std::vector<int>> edge_users; // which pairs use each edge
    std::map<int, int> node_freq;
    std::map<int, std::vector<int>> node_users;

    for (int i = 0; i < (int)results.size(); ++i) {
        const auto& r = results[i];
        if (!r.reached) continue;
        const auto& path = r.final_path;

        // Count nodes
        for (int nd : path) {
            node_freq[nd]++;
            node_users[nd].push_back(i);
        }

        // Count edges
        for (size_t k = 0; k + 1 < path.size(); ++k) {
            auto key = std::make_pair(path[k], path[k+1]);
            edge_freq[key]++;
            edge_users[key].push_back(i);
        }
    }

    // --- Print edge frequency table ---
    f << "1. EDGE USAGE FREQUENCY (across all successful routes)\n"
      << "   (Higher frequency = potential bottleneck in combined optimization)\n\n";
    f << std::setw(12) << "Edge" << std::setw(10) << "Freq"
      << "    Used by pairs\n";
    f << std::string(60, '-') << "\n";

    // Sort by frequency descending
    std::vector<std::pair<std::pair<int,int>, int>> sorted_edges(
        edge_freq.begin(), edge_freq.end());
    std::sort(sorted_edges.begin(), sorted_edges.end(),
              [](const auto& a, const auto& b) { return a.second > b.second; });

    for (size_t ei = 0; ei < sorted_edges.size(); ++ei) {
        const auto& edge = sorted_edges[ei].first;
        int freq = sorted_edges[ei].second;
        f << "   " << std::setw(2) << edge.first << " -> "
          << std::setw(2) << edge.second
          << std::setw(10) << freq << "    [";
        const auto& users = edge_users[edge];
        for (size_t i = 0; i < users.size(); ++i) {
            f << "P" << users[i];
            if (i + 1 < users.size()) f << ",";
        }
        f << "]\n";
    }

    // --- Print node frequency table ---
    f << "\n2. NODE USAGE FREQUENCY (across all successful routes)\n"
      << "   (Higher frequency = critical intersection in the network)\n\n";
    f << std::setw(8) << "Node" << std::setw(10) << "Freq"
      << "    Used by pairs\n";
    f << std::string(60, '-') << "\n";

    std::vector<std::pair<int, int>> sorted_nodes(
        node_freq.begin(), node_freq.end());
    std::sort(sorted_nodes.begin(), sorted_nodes.end(),
              [](const auto& a, const auto& b) { return a.second > b.second; });

    for (size_t ni = 0; ni < sorted_nodes.size(); ++ni) {
        int node = sorted_nodes[ni].first;
        int freq = sorted_nodes[ni].second;
        f << "   " << std::setw(4) << node
          << std::setw(10) << freq << "    [";
        const auto& users = node_users[node];
        for (size_t i = 0; i < users.size(); ++i) {
            f << "P" << users[i];
            if (i + 1 < users.size()) f << ",";
        }
        f << "]\n";
    }

    // --- Shared edges (used by 2+ routes) ---
    f << "\n3. SHARED EDGES (used by 2+ routes -- combined route overlap)\n"
      << "   These edges represent the network segments where multiple S-D\n"
      << "   routes overlap. In combined route optimization, these edges\n"
      << "   would experience higher aggregate traffic load.\n\n";

    int shared_count = 0;
    for (size_t ei = 0; ei < sorted_edges.size(); ++ei) {
        const auto& edge = sorted_edges[ei].first;
        int freq = sorted_edges[ei].second;
        if (freq >= 2) {
            f << "   Edge " << edge.first << " -> " << edge.second
              << "  shared by " << freq << " routes: ";
            const auto& users = edge_users[edge];
            for (size_t i = 0; i < users.size(); ++i) {
                const auto& r = results[users[i]];
                f << "(" << r.source << "->" << r.destination << ")";
                if (i + 1 < users.size()) f << ", ";
            }
            f << "\n";
            ++shared_count;
        }
    }
    if (shared_count == 0) {
        f << "   No shared edges detected.\n";
    }

    // --- Shared nodes (used by 3+ routes) ---
    f << "\n4. CRITICAL NODES (used by 3+ routes -- key intersections)\n\n";
    int critical_count = 0;
    for (size_t ni = 0; ni < sorted_nodes.size(); ++ni) {
        int node = sorted_nodes[ni].first;
        int freq = sorted_nodes[ni].second;
        if (freq >= 3) {
            f << "   Node " << node << "  used by " << freq << " routes: ";
            const auto& users = node_users[node];
            for (size_t i = 0; i < users.size(); ++i) {
                const auto& r = results[users[i]];
                f << "(" << r.source << "->" << r.destination << ")";
                if (i + 1 < users.size()) f << ", ";
            }
            f << "\n";
            ++critical_count;
        }
    }
    if (critical_count == 0) {
        f << "   No critical nodes detected (threshold: 3+ routes).\n";
    }

    // --- Stabilized route summary ---
    f << "\n5. STABILIZED ROUTE SUMMARY\n"
      << "   Final routes after dynamic re-planning for all S-D pairs:\n\n";

    int total_reroutes = 0;
    int total_reached  = 0;
    double total_cost  = 0;
    int successful     = 0;

    f << std::setw(5)  << "Pair"
      << std::setw(8)  << "Src"
      << std::setw(8)  << "Dst"
      << std::setw(12) << "Init Cost"
      << std::setw(12) << "Final Cost"
      << std::setw(10) << "Reroutes"
      << std::setw(10) << "Reached"
      << "  Final Path\n";
    f << std::string(100, '-') << "\n";

    for (int i = 0; i < (int)results.size(); ++i) {
        const auto& r = results[i];
        f << std::setw(5) << i
          << std::setw(8) << r.source
          << std::setw(8) << r.destination
          << std::setw(12) << std::fixed << std::setprecision(2) << r.initial_cost
          << std::setw(12) << r.final_cost
          << std::setw(10) << r.replan_count
          << std::setw(10) << (r.reached ? "YES" : "NO")
          << "  " << path_to_string(r.final_path) << "\n";

        total_reroutes += r.replan_count;
        if (r.reached) {
            total_reached++;
            total_cost += r.final_cost;
            successful++;
        }
    }

    f << std::string(100, '-') << "\n";
    f << "\n  SUMMARY STATISTICS:\n"
      << "    Total S-D pairs processed : " << results.size() << "\n"
      << "    Successfully reached      : " << total_reached << " / " << results.size() << "\n"
      << "    Total reroutes across all  : " << total_reroutes << "\n"
      << "    Average final cost (succ.) : "
      << (successful > 0 ? total_cost / successful : 0.0) << "\n"
      << "    Total unique edges used    : " << edge_freq.size() << "\n"
      << "    Shared edges (2+ routes)   : " << shared_count << "\n"
      << "    Total unique nodes used    : " << node_freq.size() << "\n"
      << "    Critical nodes (3+ routes) : " << critical_count << "\n";

    // --- Combined route optimization insight ---
    f << "\n6. COMBINED ROUTE OPTIMIZATION INSIGHT\n\n"
      << "   In a pure independent optimization, each S-D pair is solved\n"
      << "   without considering traffic from other pairs. The analysis above\n"
      << "   shows which edges/nodes are over-utilized when routes are computed\n"
      << "   independently.\n\n"
      << "   Key observation for combined optimization:\n"
      << "   - Edges with frequency >= 2 would benefit from load balancing\n"
      << "   - Critical nodes (freq >= 3) are bottleneck intersections\n"
      << "   - If routes were computed jointly (considering aggregate traffic),\n"
      << "     some routes would shift to alternative paths to reduce\n"
      << "     congestion on shared segments.\n\n"
      << "   This forms the basis for iterative combined optimization:\n"
      << "   1. Compute all routes independently (current approach)\n"
      << "   2. Measure edge/node frequencies\n"
      << "   3. Increase traffic weights on high-frequency edges\n"
      << "   4. Re-optimize routes with updated weights\n"
      << "   5. Repeat until route assignment stabilizes\n";

    f << "\n================================================================\n"
      << "  End of Network Analysis\n"
      << "================================================================\n";

    f.close();
    std::cout << "  Network analysis saved -> " << filename << "\n";
}

// =============================================================================
//  SECTION 12b -- Stabilization Analysis & Comparison
// =============================================================================

void analyze_stabilization(
    const std::vector<PairResult>& independent_results,
    const std::vector<PairResult>& combined_results,
    const std::vector<CombinedIterResult>& history,
    const std::string& filename)
{
    std::ofstream f(filename);

    f << "================================================================\n"
      << "  COMBINED ROUTE OPTIMIZATION: COMPARISON REPORT\n"
      << "================================================================\n\n";

    // --- Convergence History ---
    f << "1. CONVERGENCE HISTORY\n"
      << "   Shows how average route cost changes across combined iterations.\n\n";
    f << std::setw(10) << "Iter"
      << std::setw(14) << "Avg Cost"
      << std::setw(14) << "Change %"
      << std::setw(14) << "Reroutes"
      << std::setw(16) << "Route Changes" << "\n";
    f << std::string(68, '-') << "\n";

    for (const auto& h : history) {
        f << std::setw(10) << h.iteration
          << std::setw(14) << std::fixed << std::setprecision(2) << h.avg_cost
          << std::setw(13) << std::setprecision(2) << (h.cost_change_pct * 100) << "%"
          << std::setw(14) << h.total_reroutes
          << std::setw(16) << h.route_changes << "\n";
    }

    // --- Per-Pair Comparison ---
    f << "\n2. PER-PAIR COMPARISON: INDEPENDENT vs COMBINED\n"
      << "   Shows cost difference and route changes per S-D pair.\n\n";
    f << std::setw(5)  << "Pair"
      << std::setw(6)  << "Src"
      << std::setw(6)  << "Dst"
      << std::setw(14) << "Indep Cost"
      << std::setw(14) << "Comb Cost"
      << std::setw(12) << "Diff %"
      << std::setw(14) << "Route Same?"
      << "  Independent Path -> Combined Path\n";
    f << std::string(110, '-') << "\n";

    double total_indep = 0, total_comb = 0;
    int improved = 0, worsened = 0, same_route = 0;
    int indep_succ = 0, comb_succ = 0;

    int count = std::min(independent_results.size(), combined_results.size());
    for (int i = 0; i < count; ++i) {
        const auto& ir = independent_results[i];
        const auto& cr = combined_results[i];

        double diff_pct = 0;
        if (ir.reached && ir.final_cost > 0)
            diff_pct = (cr.final_cost - ir.final_cost) / ir.final_cost * 100;

        bool routes_same = (ir.final_path == cr.final_path);
        if (routes_same) same_route++;

        if (ir.reached) { total_indep += ir.final_cost; indep_succ++; }
        if (cr.reached) { total_comb  += cr.final_cost; comb_succ++;  }
        if (cr.reached && ir.reached) {
            if (cr.final_cost < ir.final_cost) improved++;
            else if (cr.final_cost > ir.final_cost) worsened++;
        }

        f << std::setw(5)  << i
          << std::setw(6)  << ir.source
          << std::setw(6)  << ir.destination
          << std::setw(14) << std::fixed << std::setprecision(2)
          << (ir.reached ? ir.final_cost : 0.0)
          << std::setw(14) << (cr.reached ? cr.final_cost : 0.0)
          << std::setw(11) << std::setprecision(1) << diff_pct << "%"
          << std::setw(14) << (routes_same ? "YES" : "NO")
          << "  " << path_to_string(ir.final_path)
          << " -> " << path_to_string(cr.final_path) << "\n";
    }

    f << std::string(110, '-') << "\n";

    // --- Summary ---
    f << "\n3. OVERALL COMPARISON SUMMARY\n\n";
    f << "   Independent optimization:\n"
      << "     Successful routes : " << indep_succ << " / " << count << "\n"
      << "     Average cost      : " << std::fixed << std::setprecision(2)
      << (indep_succ > 0 ? total_indep / indep_succ : 0.0) << "\n\n";
    f << "   Combined optimization (final iteration):\n"
      << "     Successful routes : " << comb_succ << " / " << count << "\n"
      << "     Average cost      : "
      << (comb_succ > 0 ? total_comb / comb_succ : 0.0) << "\n\n";
    f << "   Pairs improved (lower cost with combined) : " << improved << "\n"
      << "   Pairs worsened (higher cost)              : " << worsened << "\n"
      << "   Pairs with same final route               : " << same_route
      << " / " << count << "\n";

    double overall_change = 0;
    if (indep_succ > 0) {
        double avg_i = total_indep / indep_succ;
        double avg_c = (comb_succ > 0) ? total_comb / comb_succ : avg_i;
        overall_change = (avg_c - avg_i) / avg_i * 100;
    }
    f << "   Overall avg cost change                   : "
      << std::setprecision(2) << overall_change << "%\n";

    f << "\n   Interpretation:\n";
    if (overall_change < -1.0) {
        f << "   -> Combined optimization REDUCED average cost.\n"
          << "      Shared-edge traffic consideration led to better path diversity.\n";
    } else if (overall_change > 1.0) {
        f << "   -> Combined optimization INCREASED average cost.\n"
          << "      This is expected: routes now account for aggregate traffic,\n"
          << "      yielding more realistic (but costlier) individual paths.\n"
          << "      The NETWORK as a whole is more balanced.\n";
    } else {
        f << "   -> Combined and independent results are nearly identical.\n"
          << "      The network has sufficient capacity for independent routing.\n";
    }

    f << "\n   Combined iterations until stabilization : " << history.size() << "\n";
    if (!history.empty()) {
        f << "   Final convergence change                : "
          << std::setprecision(2) << (history.back().cost_change_pct * 100) << "%\n";
    }

    f << "\n================================================================\n"
      << "  End of Comparison Report\n"
      << "================================================================\n";

    f.close();
    std::cout << "  Comparison report saved -> " << filename << "\n";
}

// =============================================================================
//  SECTION 13 -- MAIN
// =============================================================================

static void print_summary_table(
    const std::vector<PairResult>& results, const std::string& label)
{
    std::cout << "\n  " << std::setw(5) << "Pair"
              << std::setw(6)  << "Src"
              << std::setw(6)  << "Dst"
              << std::setw(11) << "InitCost"
              << std::setw(11) << "FinalCost"
              << std::setw(9)  << "Reroutes"
              << std::setw(9)  << "Reached"
              << "  Final Path\n";
    std::cout << "  " << std::string(80, '-') << "\n";

    int total_reroutes = 0, total_reached = 0;
    double total_cost = 0;

    for (int i = 0; i < (int)results.size(); ++i) {
        const auto& r = results[i];
        std::cout << "  " << std::setw(5) << i
                  << std::setw(6) << r.source
                  << std::setw(6) << r.destination
                  << std::setw(11) << std::fixed << std::setprecision(2) << r.initial_cost
                  << std::setw(11) << r.final_cost
                  << std::setw(9)  << r.replan_count
                  << std::setw(9)  << (r.reached ? "YES" : "NO")
                  << "  " << path_to_string(r.final_path) << "\n";

        total_reroutes += r.replan_count;
        if (r.reached) { total_reached++; total_cost += r.final_cost; }
    }

    std::cout << "\n  Total pairs    : " << results.size()
              << "\n  Reached dest.  : " << total_reached << " / " << results.size()
              << "\n  Total reroutes : " << total_reroutes
              << "\n  Avg final cost : "
              << (total_reached > 0 ? total_cost / total_reached : 0.0) << "\n";
}

int main() {
    print_banner("PSO-ACO Dynamic Path Planner  (Wu et al. 2020)");
    std::cout << "  Extended: ALL S-D Pairs + Combined Route Optimization\n";

    // -- Load config --
    Config cfg = load_config("config.txt");

    if (cfg.random_seed != 0) srand(cfg.random_seed);
    else                       srand(static_cast<unsigned>(time(nullptr)));

    std::cout << "\n[CFG] map=" << cfg.map_file
              << "  pairs_file=" << cfg.pairs_file
              << "  combined_opt=" << cfg.combined_opt << "\n";

    // -- Load map --
    int n = 0;
    std::vector<Edge> original_edges = load_map(cfg.map_file, n);
    auto adj = build_adjacency(original_edges, n);

    std::cout << "[MAP] " << n << " nodes, "
              << original_edges.size() << " directed edges loaded.\n";

    std::cout << "\n[INIT] Initial Road Condition Factors:\n";
    std::cout << "  " << std::setw(12) << "Edge"
              << std::setw(10) << "Length"
              << std::setw(8)  << "Lanes"
              << std::setw(10) << "RdWidth"
              << std::setw(10) << "C(t)"
              << std::setw(10) << "R(t)" << "\n";
    for (const auto& e : original_edges) {
        double C = congestion_coeff(e, cfg.avg_vehicle_len);
        double R = road_condition_factor(e, cfg.avg_vehicle_len);
        std::cout << "  "
                  << std::setw(4) << e.from << " -> " << std::setw(4) << e.to
                  << std::setw(10) << std::fixed << std::setprecision(1) << e.length
                  << std::setw(8)  << e.lanes
                  << std::setw(10) << std::setprecision(1) << e.road_width
                  << std::setw(10) << std::setprecision(4) << C
                  << std::setw(10) << std::setprecision(2) << R << "\n";
    }

    // -- Load vehicle types --
    auto vehicle_types = load_vehicle_types(cfg.vehicle_types_file);
    std::cout << "\n[VEHICLES] " << vehicle_types.size()
              << " vehicle types loaded from " << cfg.vehicle_types_file << ":\n";
    for (const auto& vp : vehicle_types) {
        const auto& vt = vp.second;
        std::cout << "  " << std::setw(12) << vt.name
                  << "  W=" << std::setprecision(1) << vt.width
                  << "m  H=" << vt.height
                  << "m  L=" << vt.length
                  << "m  minLanes=" << vt.min_lanes_required
                  << "  minRdW=" << vt.min_road_width << "m\n";
    }

    // -- Load S-D pairs --
    std::vector<SDPair> sd_pairs = load_sd_pairs(cfg.pairs_file);
    std::cout << "\n[PAIRS] " << sd_pairs.size()
              << " source-destination pairs loaded from " << cfg.pairs_file << ":\n";
    for (int i = 0; i < (int)sd_pairs.size(); ++i) {
        std::cout << "  P" << i << ": " << sd_pairs[i].src
                  << " -> " << sd_pairs[i].dst
                  << "  vehicle=" << sd_pairs[i].vehicle_type << "\n";
    }

    // -- Validate pairs --
    for (int i = 0; i < (int)sd_pairs.size(); ++i) {
        int src = sd_pairs[i].src, dst = sd_pairs[i].dst;
        if (src >= n || dst >= n || src < 0 || dst < 0) {
            std::cerr << "[ERROR] Pair P" << i << " (" << src << "->" << dst
                      << ") has node out of range (max " << n-1 << ").\n";
            return 1;
        }
        if (src == dst) {
            std::cerr << "[ERROR] Pair P" << i << " has src == dst ("
                      << src << "). Skipping is not supported.\n";
            return 1;
        }
        // Validate vehicle type exists
        if (vehicle_types.find(sd_pairs[i].vehicle_type) == vehicle_types.end()) {
            std::cerr << "[WARN] Vehicle type '" << sd_pairs[i].vehicle_type
                      << "' not found. Using 'privatecar'.\n";
            sd_pairs[i].vehicle_type = "privatecar";
        }
    }

    // =========================================================================
    //  FAIR COMPARISON: PSO-Optimized vs Fixed Parameters
    //  For each S-D pair:
    //    1. Run PSO to find optimal (alpha, beta, rho)
    //    2. Set per-pair deterministic seed
    //    3. Run ACO + Dynamic with PSO-tuned params  -> PSO result
    //    4. Reset to SAME per-pair seed
    //    5. Run ACO + Dynamic with Fixed params      -> Fixed result
    //  This ensures IDENTICAL traffic conditions for both methods.
    //  The ONLY variable is the (alpha, beta, rho) values.
    // =========================================================================
    print_banner("PSO-OPTIMIZED vs FIXED PARAMETER COMPARISON");
    std::cout << "  Fixed parameters: alpha="
              << std::fixed << std::setprecision(4) << cfg.fixed_alpha
              << "  beta=" << cfg.fixed_beta
              << "  rho=" << cfg.fixed_rho << "\n"
              << "  NOTE: Both methods see IDENTICAL traffic conditions per pair.\n";

    std::ofstream pso_rlog("reroute_log.txt");
    pso_rlog << "pair_id,source,destination,step,cur_node,event,"
             << "best_cost,ar,path\n";

    std::ofstream fixed_rlog("reroute_log_fixed.txt");
    fixed_rlog << "pair_id,source,destination,step,cur_node,event,"
               << "best_cost,ar,path\n";

    std::vector<PairResult> pso_results;
    std::vector<PairResult> fixed_results;

    for (int i = 0; i < (int)sd_pairs.size(); ++i) {
        int src = sd_pairs[i].src;
        int dst = sd_pairs[i].dst;
        const VehicleType& cur_vt = vehicle_types[sd_pairs[i].vehicle_type];

        // -- Step 1: Run PSO to find optimal parameters --
        std::string pair_label = "PAIR " + std::to_string(i)
                               + " (" + std::to_string(src)
                               + " -> " + std::to_string(dst)
                               + ", " + cur_vt.name + ")";
        print_banner("PSO TUNING: " + pair_label);
        std::cout << "  Vehicle: " << cur_vt.name
                  << "  W=" << cur_vt.width << "m  L=" << cur_vt.length
                  << "m  minLanes=" << cur_vt.min_lanes_required
                  << "  minRdW=" << cur_vt.min_road_width << "m\n";

        // Use a PSO-specific seed (so PSO is reproducible)
        unsigned int pso_seed = cfg.random_seed * 1000 + i * 100;
        srand(pso_seed);

        PSOResult pso = run_pso(original_edges, adj, n, src, dst, cfg, &cur_vt);

        std::cout << "\n  [PSO] Optimal ACO parameters found:\n"
                  << "        alpha = " << std::fixed << std::setprecision(4) << pso.alpha << "\n"
                  << "        beta  = " << pso.beta  << "\n"
                  << "        rho   = " << pso.rho   << "\n"
                  << "        best_cost = " << pso.best_cost << "\n";

        // -- Step 2: Run ACO+Dynamic with PSO-tuned params --
        // Use per-pair seed for ACO + Dynamic re-planning
        unsigned int aco_seed = cfg.random_seed * 2000 + i * 200 + 7;
        srand(aco_seed);

        print_banner("PSO-TUNED RUN: " + pair_label);
        PairResult pso_result = run_aco_dynamic_only(
            original_edges, adj, n, src, dst,
            pso.alpha, pso.beta, pso.rho,
            cfg, pso_rlog, i, "PSO-TUNED", &cur_vt);

        pso_results.push_back(pso_result);

        // -- Step 3: Run ACO+Dynamic with FIXED params (SAME seed!) --
        // Reset to the EXACT SAME per-pair seed => identical traffic
        srand(aco_seed);

        print_banner("FIXED-PARAM RUN: " + pair_label);
        PairResult fixed_result = run_aco_dynamic_only(
            original_edges, adj, n, src, dst,
            cfg.fixed_alpha, cfg.fixed_beta, cfg.fixed_rho,
            cfg, fixed_rlog, i, "FIXED", &cur_vt);

        fixed_results.push_back(fixed_result);

        // -- Print per-pair comparison --
        std::cout << "\n  ========== PAIR " << i << " COMPARISON (" << src << " -> " << dst << ") ==========\n"
                  << "  PSO-Tuned:  cost=" << std::setprecision(2) << pso_result.final_cost
                  << "  path=" << path_to_string(pso_result.final_path)
                  << "  (alpha=" << std::setprecision(3) << pso.alpha
                  << " beta=" << pso.beta << " rho=" << pso.rho << ")\n"
                  << "  Fixed:      cost=" << std::setprecision(2) << fixed_result.final_cost
                  << "  path=" << path_to_string(fixed_result.final_path)
                  << "  (alpha=" << cfg.fixed_alpha
                  << " beta=" << cfg.fixed_beta << " rho=" << cfg.fixed_rho << ")\n";

        if (pso_result.reached && fixed_result.reached) {
            if (pso_result.final_cost < fixed_result.final_cost) {
                double saving = (fixed_result.final_cost - pso_result.final_cost) / fixed_result.final_cost * 100;
                std::cout << "  -> PSO WINS by " << std::setprecision(1) << saving << "% lower cost\n";
            } else if (fixed_result.final_cost < pso_result.final_cost) {
                std::cout << "  -> Fixed wins\n";
            } else {
                std::cout << "  -> TIE\n";
            }
        }
    }

    pso_rlog.close();
    fixed_rlog.close();

    // -- Summary tables --
    print_banner("PSO-OPTIMIZED SUMMARY");
    print_summary_table(pso_results, "PSO-Optimized");
    save_results(pso_results, "all_pairs_results.csv");

    print_banner("FIXED-PARAMETER SUMMARY");
    print_summary_table(fixed_results, "Fixed");
    save_results(fixed_results, "fixed_pairs_results.csv");

    // =========================================================================
    //  COMPARISON REPORT: PSO-Optimized vs Fixed Parameters
    // =========================================================================
    print_banner("FINAL COMPARISON: PSO-OPTIMIZED vs FIXED PARAMETERS");

    std::cout << "\n  " << std::setw(5) << "Pair"
              << std::setw(6)  << "Src"
              << std::setw(6)  << "Dst"
              << std::setw(14) << "PSO Cost"
              << std::setw(14) << "Fixed Cost"
              << std::setw(12) << "Diff %"
              << std::setw(10) << "Winner"
              << "  PSO(a,b,r)\n";
    std::cout << "  " << std::string(100, '-') << "\n";

    double total_pso = 0, total_fixed = 0;
    int pso_wins = 0, fixed_wins = 0, ties = 0;
    int pso_succ = 0, fixed_succ = 0;

    int count = (int)pso_results.size();
    for (int i = 0; i < count; ++i) {
        const auto& pr = pso_results[i];
        const auto& fr = fixed_results[i];

        double diff_pct = 0;
        std::string winner = "---";
        if (pr.reached) { total_pso += pr.final_cost; pso_succ++; }
        if (fr.reached) { total_fixed += fr.final_cost; fixed_succ++; }

        if (pr.reached && fr.reached && fr.final_cost > 0) {
            diff_pct = (fr.final_cost - pr.final_cost) / fr.final_cost * 100;
            if (pr.final_cost < fr.final_cost)      { winner = "PSO"; pso_wins++; }
            else if (fr.final_cost < pr.final_cost)  { winner = "FIXED"; fixed_wins++; }
            else                                      { winner = "TIE"; ties++; }
        }

        std::cout << "  " << std::setw(5) << i
                  << std::setw(6)  << pr.source
                  << std::setw(6)  << pr.destination
                  << std::setw(14) << std::fixed << std::setprecision(2)
                  << (pr.reached ? pr.final_cost : 0.0)
                  << std::setw(14)
                  << (fr.reached ? fr.final_cost : 0.0)
                  << std::setw(11) << std::setprecision(1) << diff_pct << "%"
                  << std::setw(10) << winner
                  << "  (" << std::setprecision(3) << pr.pso_alpha << ","
                  << pr.pso_beta << "," << pr.pso_rho << ")\n";
    }

    std::cout << "  " << std::string(100, '-') << "\n";

    double avg_pso   = (pso_succ > 0)   ? total_pso / pso_succ     : 0.0;
    double avg_fixed = (fixed_succ > 0)  ? total_fixed / fixed_succ : 0.0;
    double improvement = (avg_fixed > 0) ? (avg_fixed - avg_pso) / avg_fixed * 100 : 0.0;

    std::cout << "\n  OVERALL COMPARISON:\n"
              << "    PSO-Optimized   : avg cost = " << std::setprecision(2) << avg_pso
              << "  (" << pso_succ << "/" << count << " reached)\n"
              << "    Fixed Parameters: avg cost = " << avg_fixed
              << "  (" << fixed_succ << "/" << count << " reached)\n"
              << "    PSO improvement : " << std::setprecision(1) << improvement << "% lower cost\n"
              << "    PSO wins: " << pso_wins << "  Fixed wins: " << fixed_wins << "  Ties: " << ties << "\n";

    // -- Save comparison to file --
    {
        std::ofstream f("fixed_vs_pso_comparison.txt");
        f << "================================================================\n"
          << "  PSO-OPTIMIZED vs FIXED PARAMETER COMPARISON REPORT\n"
          << "  (Fair comparison: identical traffic conditions per pair)\n"
          << "================================================================\n\n"
          << "  Fixed parameters used:\n"
          << "    alpha = " << std::fixed << std::setprecision(4) << cfg.fixed_alpha << "\n"
          << "    beta  = " << cfg.fixed_beta  << "\n"
          << "    rho   = " << cfg.fixed_rho   << "\n\n"
          << "  Methodology:\n"
          << "    For each S-D pair, both methods use the SAME random seed,\n"
          << "    ensuring identical traffic noise and ACO randomness.\n"
          << "    The ONLY variable is the (alpha, beta, rho) parameter values.\n\n";

        f << "1. PER-PAIR COMPARISON\n\n"
          << std::setw(5)  << "Pair"
          << std::setw(6)  << "Src"
          << std::setw(6)  << "Dst"
          << std::setw(14) << "PSO Cost"
          << std::setw(14) << "Fixed Cost"
          << std::setw(12) << "Diff %"
          << std::setw(10) << "Winner"
          << "  PSO alpha,beta,rho\n";
        f << std::string(100, '-') << "\n";

        for (int i = 0; i < count; ++i) {
            const auto& pr = pso_results[i];
            const auto& fr = fixed_results[i];
            double diff_pct = 0;
            std::string winner = "---";
            if (pr.reached && fr.reached && fr.final_cost > 0) {
                diff_pct = (fr.final_cost - pr.final_cost) / fr.final_cost * 100;
                if (pr.final_cost < fr.final_cost)      winner = "PSO";
                else if (fr.final_cost < pr.final_cost)  winner = "FIXED";
                else                                      winner = "TIE";
            }
            f << std::setw(5) << i
              << std::setw(6) << pr.source
              << std::setw(6) << pr.destination
              << std::setw(14) << std::fixed << std::setprecision(2)
              << (pr.reached ? pr.final_cost : 0.0)
              << std::setw(14)
              << (fr.reached ? fr.final_cost : 0.0)
              << std::setw(11) << std::setprecision(1) << diff_pct << "%"
              << std::setw(10) << winner
              << "  " << std::setprecision(4) << pr.pso_alpha << ","
              << pr.pso_beta << "," << pr.pso_rho << "\n";
        }

        f << std::string(100, '-') << "\n";

        f << "\n2. OVERALL SUMMARY\n\n"
          << "   PSO-Optimized:\n"
          << "     Successful routes : " << pso_succ << " / " << count << "\n"
          << "     Average cost      : " << std::setprecision(2) << avg_pso << "\n\n"
          << "   Fixed Parameters (alpha=" << std::setprecision(4) << cfg.fixed_alpha
          << ", beta=" << cfg.fixed_beta << ", rho=" << cfg.fixed_rho << "):\n"
          << "     Successful routes : " << fixed_succ << " / " << count << "\n"
          << "     Average cost      : " << std::setprecision(2) << avg_fixed << "\n\n"
          << "   PSO improvement     : " << std::setprecision(1) << improvement << "% lower cost\n"
          << "   PSO wins            : " << pso_wins << "\n"
          << "   Fixed wins          : " << fixed_wins << "\n"
          << "   Ties                : " << ties << "\n\n";

        if (improvement > 0.5) {
            f << "   CONCLUSION: PSO-optimized parameters OUTPERFORM fixed parameters.\n"
              << "   The PSO tuning of (alpha, beta, rho) provides a " << std::setprecision(1)
              << improvement << "% cost reduction\n"
              << "   on average compared to using fixed midpoint values.\n"
              << "   This validates the PSO-ACO hybrid approach proposed in the paper.\n";
        } else if (improvement < -0.5) {
            f << "   CONCLUSION: Fixed parameters slightly outperform PSO-optimized parameters.\n";
        } else {
            f << "   CONCLUSION: Both methods yield similar results on this network.\n";
        }

        f << "\n3. PER-PAIR PATH COMPARISON\n\n";
        for (int i = 0; i < count; ++i) {
            const auto& pr = pso_results[i];
            const auto& fr = fixed_results[i];
            f << "   Pair " << i << " (" << pr.source << " -> " << pr.destination << "):\n"
              << "     PSO   path: " << path_to_string(pr.final_path)
              << "  cost=" << std::setprecision(2) << pr.final_cost << "\n"
              << "     Fixed path: " << path_to_string(fr.final_path)
              << "  cost=" << fr.final_cost << "\n"
              << "     PSO params: alpha=" << std::setprecision(4) << pr.pso_alpha
              << " beta=" << pr.pso_beta << " rho=" << pr.pso_rho << "\n\n";
        }

        f << "================================================================\n"
          << "  End of Comparison Report\n"
          << "================================================================\n";
        f.close();
        std::cout << "\n  Comparison report saved -> fixed_vs_pso_comparison.txt\n";
    }

    // -- Network analysis --
    analyze_network(pso_results, original_edges, n, "network_analysis.txt");

    // =========================================================================
    //  STEP B: COMBINED ROUTE OPTIMIZATION (matches flowchart Step B)
    //  Uses fixed alpha/beta/rho through run_single_pair (which uses PSO inside),
    //  with vehicle type constraint. Iterates until routes stabilize.
    // =========================================================================
    if (cfg.combined_opt) {
        print_banner("STEP B: COMBINED ROUTE OPTIMIZATION");
        std::cout << "  combined_iters = " << cfg.combined_iters
                  << "  stability_threshold = " << cfg.stability_thresh
                  << "  weight = " << cfg.combined_weight << "\n";

        auto combined_pair =
            run_combined_optimization(original_edges, adj, n,
                                      sd_pairs, cfg, vehicle_types);
        auto& combined_results = combined_pair.first;
        auto& combined_history = combined_pair.second;

        // Save combined results
        save_results(combined_results, "combined_pairs_results.csv");

        // Network analysis for combined
        analyze_network(combined_results, original_edges, n,
                        "network_analysis_combined.txt");

        // Stabilization analysis
        analyze_stabilization(pso_results, combined_results, combined_history,
                              "combined_comparison.txt");

        std::cout << "\n  [COMBINED] Combined route optimization complete.\n";
    } else {
        std::cout << "\n  [INFO] combined_opt=0 in config -- Step B skipped.\n";
    }

    // -- Final output listing --
    std::cout << "\n  OUTPUT FILES:\n";
    std::cout << "  Reroute log (PSO)         -> reroute_log.txt\n";
    std::cout << "  Reroute log (Fixed)       -> reroute_log_fixed.txt\n";
    std::cout << "  Results CSV (PSO)         -> all_pairs_results.csv\n";
    std::cout << "  Results CSV (Fixed)       -> fixed_pairs_results.csv\n";
    std::cout << "  Network analysis          -> network_analysis.txt\n";
    std::cout << "  PSO vs Fixed comparison   -> fixed_vs_pso_comparison.txt\n";
    if (cfg.combined_opt) {
        std::cout << "  Combined results CSV      -> combined_pairs_results.csv\n";
        std::cout << "  Combined network analysis -> network_analysis_combined.txt\n";
        std::cout << "  Combined comparison       -> combined_comparison.txt\n";
    }

    print_banner("Done. PSO vs Fixed comparison complete.");
    return 0;
}
