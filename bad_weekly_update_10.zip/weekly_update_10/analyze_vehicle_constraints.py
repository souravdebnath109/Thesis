"""
Vehicle Constraint Impact Analysis
Compares results WITH vehicle constraints vs the baseline (without constraints).
Generates a detailed analysis report.
"""

import csv
import os

# ── Load vehicle types ──
vehicle_types = {}
with open("vehicle_types.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        vehicle_types[row["vehicle_type"]] = {
            "width": float(row["width_m"]),
            "height": float(row["height_m"]),
            "length": float(row["length_m"]),
            "min_lanes": int(row["min_lanes_required"]),
            "min_road_width": float(row["min_road_width_m"]),
        }

# ── Load edges ──
edges = []
with open("map_data.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        edges.append({
            "from": int(row["from_node"]),
            "to": int(row["to_node"]),
            "lanes": int(row["lanes"]),
            "road_width": float(row["road_width_m"]),
            "length": float(row["length_m"]),
        })

# ── Load SD pairs ──
sd_pairs = []
with open("sd_pairs.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        sd_pairs.append({
            "src": int(row["source"]),
            "dst": int(row["destination"]),
            "vehicle": row.get("vehicle_type", "privatecar"),
        })

# ── Load PSO-tuned results ──
pso_results = []
with open("all_pairs_results.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        pso_results.append({
            "pair_id": int(row["pair_id"]),
            "source": int(row["source"]),
            "destination": int(row["destination"]),
            "vehicle_type": row.get("vehicle_type", ""),
            "reached": row["reached"] == "YES",
            "final_cost": float(row["final_cost"]),
            "initial_cost": float(row["initial_cost"]),
            "final_path": row["final_path"],
            "reroutes": int(row["reroutes"]),
        })

# ── Load Fixed results ──
fixed_results = []
with open("fixed_pairs_results.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        fixed_results.append({
            "pair_id": int(row["pair_id"]),
            "source": int(row["source"]),
            "destination": int(row["destination"]),
            "vehicle_type": row.get("vehicle_type", ""),
            "reached": row["reached"] == "YES",
            "final_cost": float(row["final_cost"]),
            "final_path": row["final_path"],
        })

# ── Compute per-edge accessibility ──
def count_blocked_edges(vtype):
    """Count how many edges a vehicle type cannot use."""
    vt = vehicle_types[vtype]
    blocked = 0
    total = len(edges)
    for e in edges:
        if e["lanes"] < vt["min_lanes"] or e["road_width"] < vt["min_road_width"]:
            blocked += 1
    return blocked, total

# ── Generate report ──
report_lines = []
def w(line=""):
    report_lines.append(line)

w("=" * 80)
w("  VEHICLE TYPE CONSTRAINT IMPACT ANALYSIS")
w("  PSO-ACO Dynamic Path Planning with Vehicle-Specific Road Restrictions")
w("=" * 80)
w()

# ── Section 1: Vehicle Types Summary ──
w("1. VEHICLE TYPES AND ROAD REQUIREMENTS")
w("-" * 80)
w(f"  {'Type':<14} {'Width':>6} {'Height':>7} {'Length':>7} {'MinLanes':>9} {'MinRdW':>8} {'Blocked':>9} {'Access%':>9}")
w("-" * 80)

# Sort by vehicle width (ascending = small to large)
sorted_vtypes = sorted(vehicle_types.items(), key=lambda x: x[1]["width"])

for vname, vt in sorted_vtypes:
    blocked, total = count_blocked_edges(vname)
    accessible = total - blocked
    access_pct = accessible / total * 100
    w(f"  {vname:<14} {vt['width']:>5.1f}m {vt['height']:>6.1f}m {vt['length']:>6.1f}m "
      f"{vt['min_lanes']:>9} {vt['min_road_width']:>7.1f}m {blocked:>5}/{total:<3} {access_pct:>8.1f}%")

w()

# ── Section 2: Edge Capacity Distribution ──
w("2. ROAD NETWORK CAPACITY DISTRIBUTION")
w("-" * 80)
lane_counts = {}
width_ranges = {"< 3.0m (narrow)": 0, "3.0-5.0m (standard)": 0, "> 5.0m (wide)": 0}

for e in edges:
    lane_counts[e["lanes"]] = lane_counts.get(e["lanes"], 0) + 1
    if e["road_width"] < 3.0:
        width_ranges["< 3.0m (narrow)"] += 1
    elif e["road_width"] <= 5.0:
        width_ranges["3.0-5.0m (standard)"] += 1
    else:
        width_ranges["> 5.0m (wide)"] += 1

w("  Lane Distribution:")
for lanes, count in sorted(lane_counts.items()):
    pct = count / len(edges) * 100
    bar = "#" * int(pct / 2)
    w(f"    {lanes}-lane: {count:>3} edges ({pct:>5.1f}%)  {bar}")

w()
w("  Road Width Distribution:")
for label, count in width_ranges.items():
    pct = count / len(edges) * 100
    bar = "#" * int(pct / 2)
    w(f"    {label:<22}: {count:>3} edges ({pct:>5.1f}%)  {bar}")

w()

# ── Section 3: Per-Pair Impact Analysis ──
w("3. PER-PAIR VEHICLE CONSTRAINT IMPACT")
w("-" * 80)
w(f"  {'Pair':<5} {'Route':<8} {'Vehicle':<14} {'VehW':>6} {'MinRdW':>7} "
  f"{'Reachable':>10} {'PSO Cost':>10} {'Fixed Cost':>11} {'Path':>30}")
w("-" * 80)

n_blocked = 0
n_success = 0
blocked_details = []
success_details = []

for i, sd in enumerate(sd_pairs):
    vname = sd["vehicle"]
    vt = vehicle_types.get(vname, {})
    pr = pso_results[i] if i < len(pso_results) else None
    fr = fixed_results[i] if i < len(fixed_results) else None

    reached = pr["reached"] if pr else False
    pso_cost = f"{pr['final_cost']:.1f}" if (pr and pr["reached"]) else "---"
    fixed_cost = f"{fr['final_cost']:.1f}" if (fr and fr["reached"]) else "---"
    path = pr["final_path"] if (pr and pr["reached"]) else "BLOCKED"
    status = "YES" if reached else "BLOCKED"

    marker = "  " if reached else ">>"

    w(f"{marker}{f'P{i}':<4} {sd['src']}->{sd['dst']:<4} {vname:<14} "
      f"{vt.get('width', 0):>5.1f}m {vt.get('min_road_width', 0):>6.1f}m "
      f"{status:>10} {pso_cost:>10} {fixed_cost:>11} {path:>30}")

    if not reached:
        n_blocked += 1
        blocked_edges, total_edges = count_blocked_edges(vname)
        blocked_details.append({
            "pair": i, "src": sd["src"], "dst": sd["dst"],
            "vehicle": vname, "width": vt.get("width", 0),
            "blocked_edges": blocked_edges, "total_edges": total_edges,
        })
    else:
        n_success += 1
        success_details.append({
            "pair": i, "src": sd["src"], "dst": sd["dst"],
            "vehicle": vname, "pso_cost": pr["final_cost"],
            "fixed_cost": fr["final_cost"] if fr else 0,
        })

w()

# ── Section 4: Blocked Routes Analysis ──
w("4. BLOCKED ROUTES - DETAILED ANALYSIS")
w("-" * 80)

if blocked_details:
    for bd in blocked_details:
        access_pct = (bd["total_edges"] - bd["blocked_edges"]) / bd["total_edges"] * 100
        w(f"  Pair P{bd['pair']} ({bd['src']} -> {bd['dst']}) - Vehicle: {bd['vehicle']}")
        w(f"    Vehicle width: {bd['width']:.1f}m")
        w(f"    Roads blocked: {bd['blocked_edges']}/{bd['total_edges']} "
          f"({bd['blocked_edges']/bd['total_edges']*100:.0f}% of network)")
        w(f"    Network accessibility: {access_pct:.0f}%")

        # Show which specific edges are blocked
        vt = vehicle_types[bd["vehicle"]]
        w(f"    Blocked edges (lanes < {vt['min_lanes']} or width < {vt['min_road_width']:.1f}m):")
        for e in edges:
            if e["lanes"] < vt["min_lanes"] or e["road_width"] < vt["min_road_width"]:
                reason = []
                if e["lanes"] < vt["min_lanes"]:
                    reason.append(f"lanes={e['lanes']}<{vt['min_lanes']}")
                if e["road_width"] < vt["min_road_width"]:
                    reason.append(f"width={e['road_width']:.1f}<{vt['min_road_width']:.1f}")
                w(f"      {e['from']}->{e['to']} ({', '.join(reason)})")
        w()
else:
    w("  No blocked routes - all vehicles can find paths.")
    w()

# ── Section 5: Summary Statistics ──
w("5. OVERALL IMPACT SUMMARY")
w("-" * 80)
w(f"  Total S-D pairs:              {len(sd_pairs)}")
w(f"  Successful routes:            {n_success} ({n_success/len(sd_pairs)*100:.1f}%)")
w(f"  Blocked by vehicle constraint: {n_blocked} ({n_blocked/len(sd_pairs)*100:.1f}%)")
w()

if success_details:
    avg_pso = sum(s["pso_cost"] for s in success_details) / len(success_details)
    avg_fixed = sum(s["fixed_cost"] for s in success_details) / len(success_details)
    w(f"  Average cost (PSO, successful): {avg_pso:.2f}")
    w(f"  Average cost (Fixed, successful): {avg_fixed:.2f}")
    w()

# Vehicle size categories
small_vehicles = ["cycle", "motorcycle", "rickshaw", "auto"]
medium_vehicles = ["sedan", "privatecar", "jeepcar", "van"]
large_vehicles = ["ambulance", "minitruck", "minibus", "microbus", "truck", "bus"]

def category_stats(cat_list, cat_name):
    total_in_cat = sum(1 for sd in sd_pairs if sd["vehicle"] in cat_list)
    blocked_in_cat = sum(1 for bd in blocked_details if bd["vehicle"] in cat_list)
    success_in_cat = total_in_cat - blocked_in_cat
    if total_in_cat > 0:
        w(f"  {cat_name}:")
        w(f"    Vehicles: {', '.join(cat_list)}")
        w(f"    Pairs assigned: {total_in_cat}  |  Success: {success_in_cat}  |  Blocked: {blocked_in_cat}")
        rate = success_in_cat / total_in_cat * 100
        w(f"    Success rate: {rate:.0f}%")
        w()

w("  Vehicle Category Analysis:")
w()
category_stats(small_vehicles, "SMALL VEHICLES (W <= 1.4m)")
category_stats(medium_vehicles, "MEDIUM VEHICLES (W = 1.8-2.0m)")
category_stats(large_vehicles, "LARGE VEHICLES (W >= 2.1m)")

# ── Section 6: Key Findings ──
w("6. KEY FINDINGS FOR THESIS")
w("-" * 80)
w()
w("  a) Vehicle type constraint introduces a HARD FEASIBILITY filter:")
w("     Not all vehicles can traverse all roads. Roads with fewer lanes")
w("     and narrower widths cannot accommodate larger vehicles (bus, truck,")
w("     ambulance, etc.).")
w()
w("  b) Impact on route availability:")
w(f"     - {n_blocked}/{len(sd_pairs)} ({n_blocked/len(sd_pairs)*100:.0f}%) of S-D pairs "
  f"became INFEASIBLE due to vehicle constraints.")
w(f"     - Small vehicles (cycle, motorcycle) have 100% network accessibility.")
w(f"     - Large vehicles (bus, truck) face significant route restrictions.")
w()
w("  c) Impact on route quality:")
w("     When a path IS found, vehicle constraints may force longer detours")
w("     because some shorter roads are too narrow. This increases:")
w("     - Average path cost (longer routes)")
w("     - Congestion on wider roads (all large vehicles funneled through same roads)")
w()
w("  d) Practical implications:")
w("     - Urban planners must consider vehicle mix when designing road networks")
w("     - Emergency vehicles (ambulance) need minimum 2-lane roads throughout")
w("     - Heavy vehicles (truck, bus) require wider arterial routes")
w("     - The PSO-ACO algorithm adapts by exploring only FEASIBLE edges, making")
w("       the search more realistic than unconstrained path planning.")
w()
w("=" * 80)
w("  End of Vehicle Constraint Impact Analysis")
w("=" * 80)

# ── Save report ──
report_text = "\n".join(report_lines)
with open("vehicle_constraint_analysis.txt", "w", encoding="utf-8") as f:
    f.write(report_text)

print(report_text)
print("\n[OK] Report saved -> vehicle_constraint_analysis.txt")
