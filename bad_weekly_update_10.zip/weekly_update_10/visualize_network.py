"""
Network Visualization for PSO-ACO Dynamic Path Planning
Shows: node positions, directed edges with road width color coding,
vehicle constraint info, and blocked/successful route markers.
"""

import csv
import math
import sys

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.lines import Line2D
except ImportError:
    print("[ERROR] matplotlib not installed. Run: pip install matplotlib")
    sys.exit(1)

# ── Load nodes ──
nodes = {}
with open("nodes.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        nid = int(row["node_id"])
        nodes[nid] = (float(row["x"]), float(row["y"]))

# ── Load edges ──
edges = []
with open("map_data.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        edges.append({
            "from": int(row["from_node"]),
            "to": int(row["to_node"]),
            "length": float(row["length_m"]),
            "lanes": int(row["lanes"]),
            "road_width": float(row["road_width_m"]),
            "f_current": float(row["f_current"]),
        })

# ── Load vehicle types ──
vehicle_types = {}
try:
    with open("vehicle_types.csv", "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            vehicle_types[row["vehicle_type"]] = {
                "width": float(row["width_m"]),
                "height": float(row["height_m"]),
                "length": float(row["length_m"]),
                "min_lanes": int(row["min_lanes_required"]),
                "min_road_width": float(row["min_road_width_m"]),
            }
except FileNotFoundError:
    print("[WARN] vehicle_types.csv not found")

# ── Load SD pairs with vehicle types ──
sd_pairs = []
try:
    with open("sd_pairs.csv", "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            sd_pairs.append({
                "src": int(row["source"]),
                "dst": int(row["destination"]),
                "vehicle": row.get("vehicle_type", "privatecar"),
            })
except FileNotFoundError:
    print("[WARN] sd_pairs.csv not found")

# ── Load results to check which pairs succeeded ──
results = []
try:
    with open("all_pairs_results.csv", "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            results.append({
                "pair_id": int(row["pair_id"]),
                "source": int(row["source"]),
                "destination": int(row["destination"]),
                "vehicle_type": row.get("vehicle_type", ""),
                "reached": row["reached"],
                "final_cost": float(row["final_cost"]),
                "final_path": row["final_path"],
            })
except FileNotFoundError:
    print("[WARN] all_pairs_results.csv not found")

# ── Plot ──
fig, axes = plt.subplots(1, 2, figsize=(20, 9))
fig.suptitle("PSO-ACO Path Planning Network with Vehicle Type Constraints",
             fontsize=14, fontweight='bold')

# ════════════════════ LEFT: Network Topology ════════════════════
ax = axes[0]
ax.set_title("Road Network (edge color = road capacity)", fontsize=11)
ax.set_aspect('equal')
ax.set_xlabel("X (m)")
ax.set_ylabel("Y (m)")
ax.grid(True, alpha=0.3)

# Color edges by lane count
lane_colors = {1: '#e74c3c', 2: '#3498db', 3: '#2ecc71'}
lane_labels = {1: '1-lane (narrow)', 2: '2-lane (standard)', 3: '3-lane (wide)'}

# Draw edges
drawn_pairs = set()
for e in edges:
    u, v = e["from"], e["to"]
    pair_key = (min(u, v), max(u, v))
    if pair_key in drawn_pairs:
        continue
    drawn_pairs.add(pair_key)

    x1, y1 = nodes[u]
    x2, y2 = nodes[v]
    color = lane_colors.get(e["lanes"], '#95a5a6')
    lw = e["lanes"] * 1.2

    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=color, lw=lw, alpha=0.7))

    # Label: lanes and road width
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    dx, dy = x2 - x1, y2 - y1
    length = math.sqrt(dx*dx + dy*dy)
    nx, ny = -dy / length * 8, dx / length * 8

    ax.text(mx + nx, my + ny,
            f"{e['lanes']}L/{e['road_width']:.1f}m",
            fontsize=6, ha='center', va='center',
            bbox=dict(boxstyle='round,pad=0.15', facecolor='white', alpha=0.8))

# Draw nodes
for nid, (x, y) in nodes.items():
    ax.plot(x, y, 'o', markersize=18, color='#2c3e50', zorder=5)
    ax.text(x, y, str(nid), ha='center', va='center',
            color='white', fontweight='bold', fontsize=10, zorder=6)

# Legend for edge colors
legend_elements = []
for lanes, color in sorted(lane_colors.items()):
    legend_elements.append(Line2D([0], [0], color=color, lw=lanes*1.2,
                                   label=lane_labels[lanes]))
ax.legend(handles=legend_elements, loc='lower left', fontsize=8)

# ════════════════════ RIGHT: Vehicle Constraint Analysis ════════════════════
ax2 = axes[1]
ax2.set_title("Vehicle Constraint Analysis (per S-D pair)", fontsize=11)
ax2.axis('off')

# Build table data
table_data = []
cell_colors = []

for i, sd in enumerate(sd_pairs):
    vtype = sd["vehicle"]
    vt = vehicle_types.get(vtype, {})
    min_w = vt.get("min_road_width", 0)
    min_l = vt.get("min_lanes", 0)
    v_len = vt.get("length", 0)

    reached = "?"
    cost = "?"
    if i < len(results):
        reached = results[i]["reached"]
        cost = f"{results[i]['final_cost']:.1f}" if results[i]["reached"] == "YES" else "BLOCKED"

    row = [f"P{i}", f"{sd['src']}->{sd['dst']}", vtype,
           f"{min_w:.1f}m", str(min_l), f"{v_len:.1f}m",
           reached, cost]
    table_data.append(row)

    if reached == "NO":
        cell_colors.append(['#fadbd8'] * 8)
    else:
        cell_colors.append(['#d5f5e3'] * 8)

col_labels = ["Pair", "Route", "Vehicle", "MinRdW", "MinLn", "VehLen", "OK?", "Cost"]

table = ax2.table(cellText=table_data, colLabels=col_labels,
                  cellColours=cell_colors,
                  colColours=['#d6eaf8'] * 8,
                  cellLoc='center', loc='center')
table.auto_set_font_size(False)
table.set_fontsize(7.5)
table.scale(1.0, 1.3)

# Summary text below table
n_total = len(sd_pairs)
n_blocked = sum(1 for r in results if r["reached"] == "NO")
n_success = n_total - n_blocked
blocked_vehicles = [results[i]["vehicle_type"] for i in range(len(results))
                    if results[i]["reached"] == "NO"]

summary = (f"Total pairs: {n_total}  |  Successful: {n_success}  |  "
           f"Blocked by vehicle constraint: {n_blocked}\n"
           f"Blocked vehicles: {', '.join(blocked_vehicles)}")
ax2.text(0.5, 0.02, summary, ha='center', va='bottom',
         fontsize=9, transform=ax2.transAxes,
         bbox=dict(boxstyle='round', facecolor='#fef9e7', alpha=0.9))

plt.tight_layout()
plt.savefig("network_graph.png", dpi=150, bbox_inches='tight')
print("[OK] Saved network_graph.png")
