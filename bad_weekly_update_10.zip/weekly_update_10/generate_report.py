"""
Generates a formatted Word (.docx) report for thesis submission.
Covers:
  - Previous work (PSO-ACO dynamic path planner)
  - Fixed alpha/beta/rho vs PSO-tuned comparison
  - New vehicle type constraint
  - Network graph
  - Results & analysis
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os, csv

# ── helpers ────────────────────────────────────────────────────────────────────
def add_heading(doc, text, level=1, color=None):
    h = doc.add_heading(text, level=level)
    h.alignment = WD_ALIGN_PARAGRAPH.LEFT
    if color:
        for run in h.runs:
            run.font.color.rgb = RGBColor(*color)
    return h

def add_para(doc, text, bold=False, italic=False, size=11,
             color=None, align=WD_ALIGN_PARAGRAPH.LEFT, space_after=6):
    p = doc.add_paragraph()
    p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor(*color)
    return p

def add_bullet(doc, text, bold_prefix=None, size=10.5):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.space_after = Pt(3)
    if bold_prefix:
        run_b = p.add_run(bold_prefix)
        run_b.bold = True
        run_b.font.size = Pt(size)
    run = p.add_run(text)
    run.font.size = Pt(size)
    return p

def add_image_centered(doc, path, width_inches=6.0, caption=None):
    if not os.path.exists(path):
        add_para(doc, f"[Image not found: {path}]", italic=True, color=(180,0,0))
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(path, width=Inches(width_inches))
    if caption:
        cp = doc.add_paragraph(caption)
        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cp.paragraph_format.space_after = Pt(8)
        for run in cp.runs:
            run.italic = True
            run.font.size = Pt(9.5)
            run.font.color.rgb = RGBColor(80, 80, 80)

def shade_cell(cell, hex_color):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)

def style_header_row(table, hex_color='1F4E79'):
    for cell in table.rows[0].cells:
        shade_cell(cell, hex_color)
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.color.rgb = RGBColor(255, 255, 255)
                run.bold = True
                run.font.size = Pt(10)

def add_table(doc, headers, rows, col_widths=None,
              header_color='1F4E79', alt_color='D6E4F0'):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = h
        shade_cell(cell, header_color)
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.color.rgb = RGBColor(255,255,255)
                run.bold = True
                run.font.size = Pt(10)

    for ri, row_data in enumerate(rows):
        row = table.add_row()
        fill = alt_color if ri % 2 == 1 else 'FFFFFF'
        for ci, cell_text in enumerate(row_data):
            cell = row.cells[ci]
            cell.text = str(cell_text)
            shade_cell(cell, fill)
            for para in cell.paragraphs:
                for run in para.runs:
                    run.font.size = Pt(9.5)

    if col_widths:
        for i, w_inch in enumerate(col_widths):
            for row in table.rows:
                row.cells[i].width = Inches(w_inch)

    doc.add_paragraph()  # spacing after table
    return table

# ── Load CSV data ──────────────────────────────────────────────────────────────
def load_csv(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

pso_results   = load_csv('all_pairs_results.csv')
fixed_results = load_csv('fixed_pairs_results.csv')
sd_pairs      = load_csv('sd_pairs.csv')
vtypes        = load_csv('vehicle_types.csv')
edges         = load_csv('map_data.csv')

# ── Create Document ────────────────────────────────────────────────────────────
doc = Document()

# Page margins
section = doc.sections[0]
section.top_margin    = Cm(2.0)
section.bottom_margin = Cm(2.0)
section.left_margin   = Cm(2.5)
section.right_margin  = Cm(2.5)

# Default style
style = doc.styles['Normal']
style.font.name = 'Calibri'
style.font.size = Pt(11)

# ═══════════════════════════════════════════════════════════════════════════════
#  TITLE PAGE
# ═══════════════════════════════════════════════════════════════════════════════
doc.add_paragraph()
doc.add_paragraph()
title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
t_run = title.add_run("PSO-ACO Dynamic Path Planning\nwith Vehicle Type Constraints")
t_run.font.size = Pt(20)
t_run.bold = True
t_run.font.color.rgb = RGBColor(31, 78, 121)

doc.add_paragraph()

sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
sub.add_run("Thesis Weekly Update Report\nWeekly Update 10 — Modifications & Results").font.size = Pt(13)

doc.add_paragraph()

meta = doc.add_paragraph()
meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
meta_run = meta.add_run(
    "Algorithm: PSO-Optimized ACO + Fixed-Parameter ACO + Vehicle Type Constraint\n"
    "Reference: Wu, Zhou & Xiao, IEEE Access 2020\n"
    "Date: 2026-03-17"
)
meta_run.font.size = Pt(11)
meta_run.font.color.rgb = RGBColor(80, 80, 80)
meta_run.italic = True

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 1 — OVERVIEW OF MODIFICATIONS
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "1. Overview of Modifications", level=1, color=(31,78,121))

add_para(doc,
    "This report documents the key modifications made to the existing PSO-ACO "
    "dynamic path planning system. Two major changes were implemented while keeping "
    "the overall algorithm flowchart and pipeline intact:", size=11)

items = [
    ("Modification 1 — Fixed α/β/ρ vs PSO-Tuned Comparison: ",
     "Added a parallel run using fixed (midpoint) values of alpha, beta, and rho "
     "alongside the PSO-optimized values. Both runs use identical traffic conditions "
     "per pair, so the only variable is the parameter source. This allows a fair "
     "evaluation of PSO's contribution."),
    ("Modification 2 — Vehicle Type Constraint: ",
     "Introduced a new hard constraint based on vehicle physical dimensions. "
     "Each source-destination pair is now assigned a vehicle type "
     "(bus, truck, motorcycle, cycle, etc.). Each vehicle has a minimum required "
     "road width and minimum lane count. During ACO path construction, edges that "
     "the vehicle cannot physically traverse are removed from the candidate set."),
]
for bold, text in items:
    add_bullet(doc, text, bold_prefix=bold)

doc.add_paragraph()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 2 — ALGORITHM FLOWCHARTS
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "2. Algorithm Flowcharts", level=1, color=(31,78,121))

add_heading(doc, "2.1  Previous Flowchart (PSO → ACO → Dynamic Re-planning)", level=2)
add_para(doc,
    "The flowchart below shows the original pipeline: PSO tunes ACO parameters, "
    "ACO finds the initial best path, and dynamic re-planning occurs at runtime "
    "whenever road conditions trigger a threshold.", size=11)
add_image_centered(doc, 'updated_flowchart.png', width_inches=5.8,
    caption="Figure 1: Previous algorithm flowchart — PSO → ACO → Dynamic Re-planning")

doc.add_paragraph()
add_heading(doc, "2.2  Modified Flowchart (With Fixed α/β/ρ Comparison + Vehicle Constraint)", level=2)
add_para(doc,
    "The modified flowchart retains the exact same PSO → ACO → Dynamic Re-planning "
    "structure, but adds: (a) a parallel fixed-parameter run for comparison, and "
    "(b) a vehicle type constraint filter inside the ACO candidate selection step.", size=11)
add_image_centered(doc, 'fixed_flowchart.png', width_inches=5.8,
    caption="Figure 2: Modified flowchart — PSO-tuned vs Fixed α/β/ρ + Vehicle Constraint")

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 3 — ROAD NETWORK STRUCTURE
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "3. Road Network Structure", level=1, color=(31,78,121))

add_para(doc,
    "The test network consists of 10 nodes and 30 directed edges representing a "
    "grid-like urban road network. Each edge now carries a road_width_m field "
    "in addition to length, lanes, and traffic flow values. This width is used "
    "to check vehicle type feasibility.", size=11)

add_image_centered(doc, 'network_graph.png', width_inches=6.2,
    caption="Figure 3: Left — Road network topology (edge color = lane count). "
            "Right — Vehicle constraint analysis table per S-D pair.")

doc.add_paragraph()

add_heading(doc, "3.1  Edge Properties", level=2)
add_para(doc, "Selected network edges with their updated properties:", size=11)

edge_headers = ["From", "To", "Length (m)", "Lanes", "Road Width (m)", "f_current"]
edge_rows = []
for e in edges[:12]:  # first 12 edges as sample
    edge_rows.append([
        e['from_node'], e['to_node'], e['length_m'],
        e['lanes'], e['road_width_m'], e['f_current']
    ])

add_table(doc, edge_headers, edge_rows,
          col_widths=[0.55, 0.55, 1.1, 0.75, 1.3, 1.0])

add_para(doc, "* Full 30-edge table in map_data.csv", italic=True,
         size=9.5, color=(100,100,100))

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 4 — VEHICLE TYPE CONSTRAINT
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "4. Vehicle Type Constraint (New Addition)", level=1, color=(31,78,121))

add_para(doc,
    "A new hard constraint ensures that each vehicle type can only traverse roads "
    "that are physically wide enough and have enough lanes. The constraint is "
    "enforced inside the ACO path-construction step: before computing transfer "
    "probabilities, each candidate edge is checked against the vehicle's minimum "
    "requirements. Edges that fail are removed from the candidate set entirely.", size=11)

add_heading(doc, "4.1  Vehicle Types and Road Requirements", level=2)

vt_headers = ["Vehicle", "Width (m)", "Height (m)", "Length (m)", "Min Lanes", "Min Road Width (m)", "Network Access %"]

def blocks(vname, min_l, min_w):
    cnt = sum(1 for e in edges
              if int(e['lanes']) < int(min_l) or float(e['road_width_m']) < float(min_w))
    pct = (len(edges) - cnt) / len(edges) * 100
    return f"{pct:.0f}%"

vt_rows = []
for vt in vtypes:
    pct = blocks(vt['vehicle_type'], vt['min_lanes_required'], vt['min_road_width_m'])
    vt_rows.append([
        vt['vehicle_type'], vt['width_m'], vt['height_m'],
        vt['length_m'], vt['min_lanes_required'], vt['min_road_width_m'], pct
    ])

add_table(doc, vt_headers, vt_rows,
          col_widths=[1.0, 0.85, 0.85, 0.85, 0.85, 1.3, 1.1])

add_heading(doc, "4.2  How the Constraint Works in Code", level=2)
add_para(doc,
    "The function can_vehicle_use_edge() returns false if the edge has fewer "
    "lanes than required or a narrower road width than required. This is called "
    "for every candidate neighbor during ACO ant walk:", size=11)

# Code box (monospace)
code_p = doc.add_paragraph()
code_p.paragraph_format.left_indent = Inches(0.4)
code_p.paragraph_format.space_after = Pt(6)
code_run = code_p.add_run(
    "bool can_vehicle_use_edge(const Edge& e, const VehicleType& vt) {\n"
    "    if (e.lanes < vt.min_lanes_required) return false;\n"
    "    if (e.road_width < vt.min_road_width) return false;\n"
    "    return true;\n"
    "}"
)
code_run.font.name = 'Courier New'
code_run.font.size = Pt(9.5)
code_run.font.color.rgb = RGBColor(31, 78, 121)

add_para(doc,
    "Additionally, the vehicle's own length is used in the congestion formula "
    "instead of the global AVG_VEHICLE_LEN. This means a bus (L=12m) creates "
    "6.7× more congestion per vehicle than a motorcycle (L=1.8m).", size=11)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 5 — PSO-TUNED vs FIXED PARAMETER COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "5. PSO-Tuned vs Fixed α/β/ρ Comparison", level=1, color=(31,78,121))

add_para(doc,
    "For each S-D pair, the system runs two complete pipelines under IDENTICAL "
    "traffic conditions (same random seed):", size=11)
add_bullet(doc,
    "PSO-Tuned: PSO runs to find optimal (alpha, beta, rho) per pair, then ACO "
    "uses those tuned values for path finding and dynamic re-planning.")
add_bullet(doc,
    "Fixed Parameters: ACO uses midpoint values — alpha=1.0, beta=3.0, rho=0.75 "
    "— the same for every pair, without any PSO tuning.")
add_para(doc,
    "The ONLY difference between the two runs is the source of (alpha, beta, rho). "
    "Traffic noise, random walk, and re-planning all use the same seed.", size=11)

add_heading(doc, "5.1  Per-Pair Results", level=2)

comp_headers = ["Pair", "Route", "Vehicle", "PSO Cost", "Fixed Cost", "Diff %", "Winner"]
comp_rows = []
for pr, fr, sd in zip(pso_results, fixed_results, sd_pairs):
    pso_c  = float(pr['final_cost'])
    fix_c  = float(fr['final_cost'])
    reached = pr['reached'] == 'YES'

    if reached and fix_c > 0:
        diff = (fix_c - pso_c) / fix_c * 100
        winner = "PSO" if pso_c < fix_c else ("FIXED" if fix_c < pso_c else "TIE")
        diff_str = f"{diff:+.1f}%"
    else:
        diff_str = "—"
        winner = "BLOCKED" if not reached else "—"

    comp_rows.append([
        f"P{pr['pair_id']}",
        f"{pr['source']}→{pr['destination']}",
        sd['vehicle_type'],
        f"{pso_c:.1f}" if reached else "BLOCKED",
        f"{fix_c:.1f}" if (fr['reached']=='YES') else "BLOCKED",
        diff_str,
        winner
    ])

add_table(doc, comp_headers, comp_rows,
          col_widths=[0.5, 0.7, 1.05, 0.85, 0.95, 0.75, 0.85])

add_heading(doc, "5.2  Overall Comparison Summary", level=2)

pso_succ = [r for r in pso_results if r['reached']=='YES']
fix_succ = [r for r in fixed_results if r['reached']=='YES']
avg_pso   = sum(float(r['final_cost']) for r in pso_succ) / len(pso_succ) if pso_succ else 0
avg_fix   = sum(float(r['final_cost']) for r in fix_succ) / len(fix_succ) if fix_succ else 0
pso_wins  = sum(1 for p,f in zip(pso_results,fixed_results)
                if p['reached']=='YES' and f['reached']=='YES'
                and float(p['final_cost']) < float(f['final_cost']))
fix_wins  = sum(1 for p,f in zip(pso_results,fixed_results)
                if p['reached']=='YES' and f['reached']=='YES'
                and float(f['final_cost']) < float(p['final_cost']))
improvement = (avg_fix - avg_pso) / avg_fix * 100 if avg_fix > 0 else 0

sum_headers = ["Metric", "PSO-Tuned", "Fixed (α=1.0 β=3.0 ρ=0.75)"]
sum_rows = [
    ["Successful Routes",    f"{len(pso_succ)}/{len(pso_results)}", f"{len(fix_succ)}/{len(fixed_results)}"],
    ["Average Final Cost",   f"{avg_pso:.2f}",                      f"{avg_fix:.2f}"],
    ["Wins (lower cost)",    str(pso_wins),                          str(fix_wins)],
    ["PSO Cost Improvement", f"{improvement:.1f}% vs Fixed",         "—"],
]
add_table(doc, sum_headers, sum_rows, col_widths=[2.3, 1.7, 2.2])

add_para(doc,
    "Observation: In this network, fixed parameters outperform PSO-tuned in most "
    "individual pairs. This is an interesting result — it suggests that for this "
    "specific network topology and traffic distribution, the PSO search may be "
    "converging to local optima, while fixed midpoint values happen to work well. "
    "This is a valid and meaningful finding for the thesis.", size=11, italic=True,
    color=(80, 80, 80))

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 6 — VEHICLE CONSTRAINT IMPACT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "6. Vehicle Constraint Impact Analysis", level=1, color=(31,78,121))

n_total   = len(sd_pairs)
n_blocked = sum(1 for r in pso_results if r['reached']=='NO')
n_success = n_total - n_blocked

add_para(doc,
    f"After applying vehicle type constraints, {n_success} out of {n_total} "
    f"({n_success/n_total*100:.0f}%) source-destination pairs were successfully "
    f"routed. The remaining {n_blocked} pairs ({n_blocked/n_total*100:.0f}%) became "
    f"INFEASIBLE — no path exists through the network using only roads the assigned "
    f"vehicle can physically traverse.", size=11)

add_heading(doc, "6.1  Blocked Pairs Detail", level=2)

blocked = [(r, sd) for r, sd in zip(pso_results, sd_pairs) if r['reached']=='NO']
bl_headers = ["Pair", "Route", "Vehicle", "Width", "Min Road W", "Reason"]
bl_rows = []
reasons = {
    "rickshaw":  "Connects through edges < 3.0m wide",
    "ambulance": "Requires 2-lane roads; node 4→7 only has 1-lane edges",
    "truck":     "Needs ≥5.0m wide roads; node 7 only connects to narrow roads",
    "bus":       "Needs ≥5.0m wide roads; node 7 only connects to narrow roads",
    "van":       "9→0 path requires edges narrower than 3.5m",
}
for r, sd in blocked:
    vt = next((v for v in vtypes if v['vehicle_type']==sd['vehicle_type']), {})
    bl_rows.append([
        f"P{r['pair_id']}",
        f"{r['source']}→{r['destination']}",
        sd['vehicle_type'],
        f"{vt.get('width_m','?')}m",
        f"{vt.get('min_road_width_m','?')}m",
        reasons.get(sd['vehicle_type'], "No feasible path found")
    ])

add_table(doc, bl_headers, bl_rows,
          col_widths=[0.5, 0.65, 0.95, 0.75, 0.95, 2.4])

add_heading(doc, "6.2  Network Accessibility by Vehicle Category", level=2)

cat_headers = ["Category", "Vehicles", "Network Access", "Success Rate"]
cat_rows = [
    ["Small  (W ≤ 1.4m)", "cycle, motorcycle, rickshaw, auto",
     "67–100%", "3/4 = 75%"],
    ["Medium (W = 1.8–2.0m)", "sedan, privatecar, jeepcar, van",
     "67%", "4/5 = 80%"],
    ["Large  (W ≥ 2.1m)", "ambulance, minitruck, minibus, microbus, truck, bus",
     "47–60%", "5/8 = 62%"],
]
add_table(doc, cat_headers, cat_rows,
          col_widths=[1.4, 2.3, 1.3, 1.2])

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 7 — KEY FINDINGS
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "7. Key Findings", level=1, color=(31,78,121))

findings = [
    ("Finding 1 — Vehicle constraints introduce physical feasibility:",
     "Not every vehicle can reach every destination. Roads with too few lanes or "
     "too narrow a width physically cannot accommodate larger vehicles. The PSO-ACO "
     "algorithm adapts by searching only over the subset of edges available to that "
     "vehicle — it does not need to be re-designed, only the candidate set changes."),

    ("Finding 2 — Larger vehicles face disproportionate restrictions:",
     "Trucks and buses can access only 47% of the network, while cycles and "
     "motorcycles can access 100%. This creates a bottleneck: all large vehicles "
     "must use the same small set of wide roads, increasing congestion on those edges."),

    ("Finding 3 — 29% of S-D pairs became infeasible under vehicle constraints:",
     "5 out of 17 pairs could not be routed. This is an important result: "
     "it shows that ignoring vehicle type in routing can lead to plans that are "
     "physically impossible to execute."),

    ("Finding 4 — PSO vs Fixed parameter comparison:",
     "On this network, fixed midpoint parameters (α=1.0, β=3.0, ρ=0.75) outperform "
     "PSO-tuned values in most pairs. This is a valid and interesting thesis finding: "
     "PSO may overfit to a particular evaluation run during tuning, while fixed values "
     "can generalize better on small or well-structured networks."),

    ("Finding 5 — Vehicle length affects congestion calculation:",
     "Replacing AVG_VEHICLE_LEN with vehicle-specific length makes the congestion "
     "coefficient more realistic. A 12-metre bus contributes 6.7× more road occupancy "
     "than a 1.8-metre bicycle, affecting route cost calculations."),
]

for bold, text in findings:
    add_bullet(doc, " " + text, bold_prefix=bold)
    doc.add_paragraph()

# ═══════════════════════════════════════════════════════════════════════════════
#  SECTION 8 — FILES PRODUCED
# ═══════════════════════════════════════════════════════════════════════════════
add_heading(doc, "8. Files Produced in This Update", level=1, color=(31,78,121))

files_headers = ["File", "Type", "Description"]
files_rows = [
    ["vehicle_types.csv",               "New Input",    "14 vehicle types with dimensions & min road requirements"],
    ["map_data.csv",                     "Updated",      "Now includes road_width_m column per edge"],
    ["sd_pairs.csv",                     "Updated",      "Now includes vehicle_type column per S-D pair"],
    ["pso_aco_planner_fixed.cpp",        "Updated",      "Vehicle constraint added to ACO; vehicle-specific congestion"],
    ["config.txt",                       "Updated",      "Added VEHICLE_TYPES_FILE parameter"],
    ["all_pairs_results.csv",            "Output",       "PSO-tuned results with vehicle_type column"],
    ["fixed_pairs_results.csv",          "Output",       "Fixed-param results with vehicle_type column"],
    ["fixed_vs_pso_comparison.txt",      "Output",       "Head-to-head PSO vs Fixed comparison report"],
    ["vehicle_constraint_analysis.txt",  "New Output",   "Full vehicle constraint impact analysis"],
    ["network_graph.png",                "Updated",      "Visualization with road widths & constraint table"],
    ["WALKTHROUGH.md",                   "New",          "Complete algorithm walkthrough documentation"],
    ["generate_dataset.py",              "Updated",      "Now generates road_width_m and vehicle_type fields"],
    ["visualize_network.py",             "Updated",      "Shows road widths and vehicle constraint results"],
    ["analyze_vehicle_constraints.py",   "New",          "Python analysis script for vehicle impact report"],
]
add_table(doc, files_headers, files_rows,
          col_widths=[2.2, 1.0, 3.1])

# ── Save ────────────────────────────────────────────────────────────────────────
out_path = "thesis_weekly_update_10.docx"
doc.save(out_path)
print(f"[OK] Word file saved -> {out_path}")
