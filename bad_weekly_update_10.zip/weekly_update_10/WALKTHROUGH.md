# PSO-ACO Dynamic Path Planner — Complete Project Walkthrough
## With Vehicle Type Constraint Extension

**Based on:** Wu, Zhou & Xiao, "Dynamic Path Planning Based on Improved Ant Colony Algorithm in Traffic Congestion," IEEE Access 2020

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [File Structure](#2-file-structure)
3. [Data Pipeline](#3-data-pipeline)
4. [Algorithm Flowchart](#4-algorithm-flowchart)
5. [Vehicle Type Constraint (New)](#5-vehicle-type-constraint-new)
6. [Code Walkthrough](#6-code-walkthrough)
7. [How to Build & Run](#7-how-to-build--run)
8. [Output Files Explained](#8-output-files-explained)
9. [Understanding the Results](#9-understanding-the-results)
10. [Key Findings for Thesis](#10-key-findings-for-thesis)

---

## 1. Project Overview

This project implements a **PSO-ACO hybrid algorithm** for dynamic path planning in
traffic-congested road networks. The system:

1. Uses **PSO (Particle Swarm Optimization)** to tune ACO parameters (alpha, beta, rho)
2. Uses **ACO (Ant Colony Optimization)** to find optimal paths from source to destination
3. Performs **Dynamic Re-planning** when road conditions change during traversal
4. Compares **PSO-tuned** vs **fixed-parameter** ACO to validate PSO's benefit
5. **[NEW]** Enforces **vehicle type constraints** — different vehicles (bus, truck, cycle,
   motorcycle, etc.) have different physical dimensions and cannot use all roads

### What Makes This Unique

- The PSO tunes ACO's 3 parameters (α, β, ρ) per source-destination pair
- Dynamic re-planning occurs during traversal when congestion spikes
- Vehicle type constraint adds a realistic physical feasibility layer
- Fair comparison methodology: same random seed for PSO-tuned and fixed-param runs

---

## 2. File Structure

```
weekly_update_10/
│
├── INPUT FILES (Data)
│   ├── config.txt                  # All configurable parameters
│   ├── map_data.csv                # Road network: edges with length, lanes, road_width, traffic
│   ├── nodes.csv                   # Node positions (x, y coordinates)
│   ├── sd_pairs.csv                # Source-destination pairs with vehicle types
│   └── vehicle_types.csv           # Vehicle dimensions & road requirements (NEW)
│
├── SOURCE CODE
│   ├── pso_aco_planner_fixed.cpp   # Main C++ planner (PSO + ACO + Dynamic + Vehicle Constraint)
│   ├── generate_dataset.py         # Generates map_data.csv, nodes.csv, sd_pairs.csv
│   ├── visualize_network.py        # Network visualization with vehicle constraint overlay
│   └── analyze_vehicle_constraints.py  # Vehicle constraint impact analysis (NEW)
│
├── OUTPUT FILES (Results)
│   ├── all_pairs_results.csv       # PSO-tuned results for all S-D pairs
│   ├── fixed_pairs_results.csv     # Fixed-param results for all S-D pairs
│   ├── fixed_vs_pso_comparison.txt # Head-to-head comparison report
│   ├── network_analysis.txt        # Network-level edge/node usage analysis
│   ├── vehicle_constraint_analysis.txt # Vehicle constraint impact report (NEW)
│   ├── reroute_log.txt             # PSO-tuned rerouting events
│   ├── reroute_log_fixed.txt       # Fixed-param rerouting events
│   └── network_graph.png           # Visual network map
│
└── DOCUMENTATION
    ├── INSTRUCTIONS.md             # Build & run instructions
    └── research_notes.md           # Research context notes
```

---

## 3. Data Pipeline

```
  generate_dataset.py
         │
         ▼
  ┌──────────────────────────────────────────────────────┐
  │  nodes.csv        (10 nodes with x,y positions)      │
  │  map_data.csv     (30 directed edges with traffic)   │
  │  sd_pairs.csv     (17 S-D pairs with vehicle types)  │
  │  vehicle_types.csv (14 vehicle types with dimensions)│
  └──────────────────────────────────────────────────────┘
         │
         ▼
  pso_aco_planner_fixed.exe    (reads config.txt + above CSVs)
         │
         ▼
  ┌──────────────────────────────────────────────────────┐
  │  all_pairs_results.csv      (PSO-tuned results)      │
  │  fixed_pairs_results.csv    (Fixed-param results)    │
  │  fixed_vs_pso_comparison.txt (comparison report)     │
  │  network_analysis.txt       (edge/node usage)        │
  │  reroute_log.txt            (rerouting events)       │
  └──────────────────────────────────────────────────────┘
         │
         ▼
  visualize_network.py  +  analyze_vehicle_constraints.py
         │
         ▼
  ┌──────────────────────────────────────────────────────┐
  │  network_graph.png                                    │
  │  vehicle_constraint_analysis.txt                      │
  └──────────────────────────────────────────────────────┘
```

---

## 4. Algorithm Flowchart

The pipeline follows **exactly** the flowchart from the paper, with vehicle constraint
added as a pre-filter in the ACO candidate selection:

```
FOR EACH S-D PAIR (with assigned vehicle type):
│
├─ PHASE 1: PSO Parameter Optimization (one-time)
│   │
│   │  Initialize swarm of particles: each with (alpha, beta, rho)
│   │  FOR each PSO iteration:
│   │    FOR each particle:
│   │      ├─ Run ACO with particle's (alpha, beta, rho) + vehicle constraint
│   │      ├─ Evaluate fitness = path cost (lower is better)
│   │      ├─ Update personal best
│   │      └─ Update global best
│   │    Update velocities & positions (formulas 6-7)
│   │  END
│   │  Output: optimal (alpha*, beta*, rho*)
│   │
├─ PHASE 2: Initial ACO Path Finding
│   │
│   │  Run full ACO with PSO-tuned (alpha*, beta*, rho*) + vehicle constraint
│   │  Each ant builds a path:
│   │    ├─ At each node, collect candidate neighbors
│   │    ├─ [NEW] FILTER: Remove edges where vehicle can't fit
│   │    │         (road_width < min_road_width OR lanes < min_lanes)
│   │    ├─ Compute transfer probability (formula 1):
│   │    │     p_ij = [tau_ij]^alpha * [1/R_ij]^beta / SUM
│   │    ├─ Roulette-wheel selection
│   │    └─ Deposit pheromone on path (formula 5)
│   │  Evaporate pheromone (formula 3)
│   │  Output: besttour (initial best path)
│   │
├─ PHASE 3: Dynamic Re-planning Loop
│   │
│   │  FOR each simulation step:
│   │    ├─ Advance one edge along best_path
│   │    ├─ Update traffic (simulate t -> t+1)
│   │    ├─ Compute new R_i(t) for all edges
│   │    ├─ CHECK TRIGGER:
│   │    │     |R_i(t) - R_i(t-1)| > delta_R_max?
│   │    │     OR R_i(t) > R_max?
│   │    │
│   │    ├─ IF TRIGGERED:
│   │    │     ├─ Re-run ACO from current node to destination
│   │    │     │   (with vehicle constraint!)
│   │    │     ├─ IF newtour < remaining besttour:
│   │    │     │     besttour <- newtour + a_r  (REROUTE)
│   │    │     └─ ELSE: keep existing path
│   │    │
│   │    └─ IF NOT TRIGGERED: continue on current path
│   │
│   │  Output: final path, final cost, reroute count
│   │
└─ COMPARE: PSO-tuned result vs Fixed-parameter result
     (identical traffic via same random seed)
```

---

## 5. Vehicle Type Constraint (New)

### 5.1 What It Does

Each S-D pair is assigned a **vehicle type** (bus, truck, motorcycle, cycle, etc.).
Each vehicle type has physical dimensions:

| Vehicle     | Width | Height | Length | Min Lanes | Min Road Width |
|-------------|-------|--------|--------|-----------|----------------|
| cycle       | 0.6m  | 1.0m   | 1.8m   | 1         | 2.5m           |
| motorcycle  | 0.8m  | 1.1m   | 2.0m   | 1         | 2.5m           |
| rickshaw    | 1.3m  | 1.8m   | 2.8m   | 1         | 3.0m           |
| auto        | 1.4m  | 1.8m   | 2.7m   | 1         | 3.0m           |
| sedan       | 1.8m  | 1.5m   | 4.5m   | 1         | 3.5m           |
| privatecar  | 1.8m  | 1.5m   | 4.5m   | 1         | 3.5m           |
| jeepcar     | 1.9m  | 1.8m   | 4.8m   | 1         | 3.5m           |
| van         | 2.0m  | 2.0m   | 5.0m   | 1         | 3.5m           |
| ambulance   | 2.1m  | 2.5m   | 5.5m   | 2         | 4.0m           |
| minitruck   | 2.2m  | 2.5m   | 5.5m   | 2         | 4.0m           |
| minibus     | 2.3m  | 2.8m   | 7.0m   | 2         | 4.5m           |
| microbus    | 2.4m  | 3.0m   | 7.5m   | 2         | 4.5m           |
| truck       | 2.5m  | 3.5m   | 10.0m  | 2         | 5.0m           |
| bus         | 2.5m  | 3.2m   | 12.0m  | 2         | 5.0m           |

### 5.2 How It's Enforced

The constraint is a **HARD filter** in the ACO path construction. When an ant at
node `cur` looks for candidate next-nodes, it checks each edge:

```cpp
bool can_vehicle_use_edge(const Edge& e, const VehicleType& vt) {
    if (e.lanes < vt.min_lanes_required) return false;
    if (e.road_width < vt.min_road_width) return false;
    return true;
}
```

If `can_vehicle_use_edge()` returns `false`, that edge is **removed from candidates**.
The ant never considers it. This means:

- Small vehicles (cycle, motorcycle) can use ALL edges → maximum route flexibility
- Large vehicles (bus, truck) can only use wide, multi-lane roads → limited routing
- Some S-D pairs become **INFEASIBLE** if no path exists using only allowed edges

### 5.3 Impact on Congestion Formula

The congestion coefficient formula uses **vehicle-specific length** instead of
the global `AVG_VEHICLE_LEN`:

```
C_i(t) = (f_current + f_in - f_out) * L_vehicle / (lanes * length)
```

A bus (L=12.0m) creates more congestion per-vehicle than a motorcycle (L=2.0m).

### 5.4 Where It's Applied

The vehicle constraint is passed through the ENTIRE pipeline:
- `run_pso()` → passes to inner ACO evaluation
- `run_aco()` → filters candidates during ant path construction
- `run_single_pair()` → Phase 1 (PSO), Phase 2 (initial ACO), Phase 3 (re-plan ACO)
- `run_aco_dynamic_only()` → same constraint in ACO + re-planning

---

## 6. Code Walkthrough

### 6.1 Data Structures (Lines ~39-115)

```cpp
struct Edge {
    int from, to;
    double length;        // metres
    int lanes;            // 1, 2, or 3
    double road_width;    // physical road width (metres) ← NEW
    double f_current, f_in, f_out;  // traffic flow
};

struct VehicleType {             // ← NEW
    std::string name;
    double width, height, length;
    int min_lanes_required;
    double min_road_width;
};

struct PairResult {
    int source, destination;
    std::string vehicle_type;    // ← NEW
    double pso_alpha, pso_beta, pso_rho;
    std::vector<int> initial_path, final_path;
    double initial_cost, final_cost;
    int replan_count;
    bool reached;
    int edges_blocked;           // ← NEW
};
```

### 6.2 Key Functions

| Function | Purpose |
|----------|---------|
| `load_config()` | Reads config.txt parameters |
| `load_map()` | Reads map_data.csv (edges with road_width) |
| `load_sd_pairs()` | Reads sd_pairs.csv (pairs with vehicle_type) |
| `load_vehicle_types()` | Reads vehicle_types.csv |
| `can_vehicle_use_edge()` | **Vehicle constraint check** |
| `congestion_coeff()` | Formula 8: C_i(t) using vehicle-specific length |
| `road_condition_factor()` | Formula 10: R_i(t) = d_i * (1 + C_i(t)) |
| `run_aco()` | ACO with vehicle-filtered candidates |
| `run_pso()` | PSO tuning with vehicle constraint forwarded |
| `run_single_pair()` | Full pipeline: PSO → ACO → Dynamic Re-plan |
| `run_aco_dynamic_only()` | ACO + Dynamic without PSO (for comparison) |
| `save_results()` | CSV output with vehicle_type column |

### 6.3 The ACO Candidate Filtering (Core Change)

In `run_aco()`, when building candidates at each node:

```cpp
// BEFORE (no vehicle constraint):
for (auto it = adj[cur].begin(); it != adj[cur].end(); ++it) {
    int nb = it->first;
    if (!visited[nb]) candidates.push_back(nb);
}

// AFTER (with vehicle constraint):
for (auto it = adj[cur].begin(); it != adj[cur].end(); ++it) {
    int nb = it->first;
    if (!visited[nb]) {
        if (vt != nullptr) {
            int eidx_check = it->second;
            if (!can_vehicle_use_edge(edges[eidx_check], *vt))
                continue;   // <-- Skip this edge! Vehicle can't fit.
        }
        candidates.push_back(nb);
    }
}
```

---

## 7. How to Build & Run

### Prerequisites
- **C++ compiler**: g++ with C++17 support
- **Python 3**: with matplotlib (for visualization)

### Step 1: Generate Dataset
```bash
python generate_dataset.py
```
This creates: `nodes.csv`, `map_data.csv`, `sd_pairs.csv`
(vehicle_types.csv is already provided)

### Step 2: Compile
```bash
g++ -O2 -std=c++17 -o pso_aco_planner_fixed pso_aco_planner_fixed.cpp
```

### Step 3: Run
```bash
./pso_aco_planner_fixed
```
This reads `config.txt` + all CSV files, and produces all output files.

### Step 4: Visualize
```bash
python visualize_network.py
python analyze_vehicle_constraints.py
```

---

## 8. Output Files Explained

### `all_pairs_results.csv` — PSO-Tuned Results
Each row = one S-D pair with PSO-optimized parameters:
```
pair_id, source, destination, vehicle_type, initial_path, initial_cost,
final_path, final_cost, reroutes, reached, pso_alpha, pso_beta, pso_rho
```

### `fixed_pairs_results.csv` — Fixed-Parameter Results
Same format, but using fixed alpha=1.0, beta=3.0, rho=0.75

### `fixed_vs_pso_comparison.txt` — Head-to-Head Report
Shows per-pair comparison: PSO cost vs Fixed cost, % difference, winner

### `vehicle_constraint_analysis.txt` — Vehicle Impact Report
Shows:
- Vehicle accessibility per type (% of network reachable)
- Which pairs are BLOCKED and why
- Detailed list of blocked edges per vehicle
- Category analysis (small/medium/large vehicles)

### `network_graph.png` — Visual Network
Left panel: Road network with edges colored by lane count
Right panel: Table showing vehicle constraint results per pair

---

## 9. Understanding the Results

### Current Results Summary

| Metric | Value |
|--------|-------|
| Total S-D pairs | 17 |
| Successful with vehicle constraint | 12 (70.6%) |
| Blocked by vehicle constraint | 5 (29.4%) |
| PSO avg cost (successful) | 385.78 |
| Fixed avg cost (successful) | 364.74 |

### Blocked Pairs and Why

| Pair | Route | Vehicle | Reason |
|------|-------|---------|--------|
| P2 | 0→3 | rickshaw | All paths from 0 go through narrow roads (width < 3.0m) |
| P8 | 4→7 | ambulance | Edge 6→7 is 1-lane/3.5m, ambulance needs 2-lane/4.0m |
| P12 | 7→0 | truck | Node 7 only connects to narrow roads (need 5.0m width) |
| P13 | 7→9 | bus | Same as truck — node 7's edges are all too narrow |
| P15 | 9→0 | van | Path requires edges through nodes with width < 3.5m |

### Network Accessibility by Vehicle Size

| Category | Vehicles | Access % | Success Rate |
|----------|----------|----------|--------------|
| Small (W ≤ 1.4m) | cycle, motorcycle, rickshaw, auto | 67-100% | 75% |
| Medium (W = 1.8-2.0m) | sedan, privatecar, jeepcar, van | 67% | 80% |
| Large (W ≥ 2.1m) | ambulance, minitruck, ... bus, truck | 47-60% | 62% |

---

## 10. Key Findings for Thesis

### Finding 1: Vehicle Constraints Create Realistic Feasibility Filtering
The vehicle type constraint converts the theoretical path planning problem into a
**physically realistic** one. Not every vehicle can use every road — this is a
fundamental real-world constraint that most routing algorithms ignore.

### Finding 2: Larger Vehicles Face Disproportionate Route Restrictions
- Trucks and buses can access only **47%** of the network
- Cycles and motorcycles can access **100%**
- This creates a **natural bottleneck**: large vehicles are funneled onto fewer roads,
  increasing congestion on those roads

### Finding 3: Vehicle Constraints Can Make Routes Infeasible
- **29% of S-D pairs** became infeasible when vehicle constraints were added
- This is particularly impactful for emergency vehicles (ambulances) that need
  to reach all areas but require wider roads

### Finding 4: The PSO-ACO Algorithm Adapts Naturally
The vehicle constraint is implemented as a **pre-filter** in the ACO candidate
selection. The algorithm doesn't need fundamental changes — it simply explores
a **reduced graph** specific to each vehicle type. This demonstrates the
algorithm's flexibility and extensibility.

### Finding 5: Congestion Impact Varies by Vehicle Length
Using vehicle-specific length in the congestion formula means:
- A bus (12.0m) contributes **6.7x more congestion** than a motorcycle (1.8m)
  per vehicle on the same road
- This makes the congestion model more realistic

---

*Generated: 2026-03-17 | PSO-ACO Dynamic Path Planner with Vehicle Type Constraints*
