"""
Dataset Generator for PSO-ACO Dynamic Path Planning
Generates map_data.csv with a 10-node road network
including: edge lengths, lane counts, road widths, and initial traffic flows

Extended: Vehicle-Type Constraint
  - Each edge now has a road_width_m column (physical width of the road)
  - sd_pairs.csv now includes a vehicle_type column
  - vehicle_types.csv defines dimensions and minimum requirements per vehicle

Based on: "Dynamic Path Planning Based on Improved Ant Colony Algorithm
           in Traffic Congestion" (Wu et al., IEEE Access 2020)
"""

import csv
import random
import math

random.seed(42)

# ─────────────────────────────────────────────
# 1. NODE POSITIONS  (x, y) in metres × 10
# ─────────────────────────────────────────────
nodes = {
    0: (0,   0),
    1: (100, 0),
    2: (200, 0),
    3: (300, 0),
    4: (0,   100),
    5: (100, 100),
    6: (200, 100),
    7: (300, 100),
    8: (100, 200),
    9: (200, 200),
}

# ─────────────────────────────────────────────
# 2. EDGE DEFINITIONS  (undirected → stored as
#    two directed rows for easy C++ parsing)
# ─────────────────────────────────────────────
undirected_edges = [
    (0, 1), (1, 2), (2, 3),       # bottom row
    (4, 5), (5, 6), (6, 7),       # middle row
    (8, 9),                        # top row
    (0, 4), (1, 5), (2, 6), (3, 7),  # verticals
    (4, 8), (5, 8), (5, 9), (6, 9),  # diagonals/verticals to top
]

# ─────────────────────────────────────────────
# Vehicle types for S-D pair assignment
# ─────────────────────────────────────────────
vehicle_types_list = [
    "cycle", "motorcycle", "rickshaw", "auto", "sedan",
    "privatecar", "jeepcar", "van", "ambulance", "minitruck",
    "minibus", "microbus", "truck", "bus"
]

def euclidean(a, b):
    x1, y1 = nodes[a]
    x2, y2 = nodes[b]
    return round(math.sqrt((x2-x1)**2 + (y2-y1)**2), 2)

def random_lanes():
    """Urban roads: 1, 2, or 3 lanes."""
    return random.choice([1, 2, 2, 3])

def road_width_from_lanes(lanes):
    """
    Estimate physical road width from number of lanes.
    Typical lane width: 3.0-3.5m for standard roads.
      1 lane  -> 3.0m  (narrow street / alley)
      2 lanes -> 5.0m  (standard two-lane road)
      3 lanes -> 7.5m  (wide arterial road)
    """
    if lanes == 1:
        return round(random.uniform(2.5, 3.5), 1)
    elif lanes == 2:
        return round(random.uniform(4.5, 5.5), 1)
    else:  # 3+ lanes
        return round(random.uniform(6.5, 8.0), 1)

def random_traffic(lanes, length):
    """
    Generate plausible initial traffic:
      f_current : vehicles currently ON the road
      f_in      : vehicles entering per time-step
      f_out     : vehicles leaving per time-step
    Kept physically reasonable so Ci(t) in [0, 1].
    """
    capacity = int(lanes * length / 5)   # rough capacity estimate
    f_current = random.randint(0, max(1, capacity // 2))
    f_in      = random.randint(0, max(1, capacity // 4))
    f_out     = random.randint(0, max(1, f_in + 1))
    return f_current, f_in, f_out

# ─────────────────────────────────────────────
# 3. WRITE  nodes.csv
# ─────────────────────────────────────────────
with open("nodes.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["node_id", "x", "y"])
    for nid, (x, y) in nodes.items():
        writer.writerow([nid, x, y])

print(f"[OK] nodes.csv  -- {len(nodes)} nodes written")

# ─────────────────────────────────────────────
# 4. WRITE  map_data.csv  (with road_width_m)
# ─────────────────────────────────────────────
# Columns:
#   from_node, to_node, length_m, lanes, road_width_m,
#   f_current, f_in, f_out
# Both directions are written so C++ can treat it as directed.
# ─────────────────────────────────────────────
rows = []
edge_id = 0
for (a, b) in undirected_edges:
    d   = euclidean(a, b)
    l   = random_lanes()
    rw  = road_width_from_lanes(l)
    fc, fi, fo = random_traffic(l, d)

    # Forward direction
    rows.append([a, b, d, l, rw, fc, fi, fo])
    # Reverse direction (same road properties, slightly varied traffic)
    fc2 = random.randint(0, max(1, int(fc * 0.8)))
    fi2 = random.randint(0, max(1, int(fi * 0.8)))
    fo2 = random.randint(0, max(1, fi2 + 1))
    rows.append([b, a, d, l, rw, fc2, fi2, fo2])
    edge_id += 1

with open("map_data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["from_node", "to_node", "length_m",
                     "lanes", "road_width_m",
                     "f_current", "f_in", "f_out"])
    for row in rows:
        writer.writerow(row)

print(f"[OK] map_data.csv -- {len(rows)} directed edges written (with road_width_m)")

# ─────────────────────────────────────────────
# 5. PRINT SUMMARY TABLE
# ─────────────────────────────────────────────
print("\n--- Edge Summary ---")
print(f"{'Edge':>12}  {'Length':>8}  {'Lanes':>5}  {'RdWidth':>8}  "
      f"{'f_cur':>6}  {'f_in':>5}  {'f_out':>6}")
for row in rows:
    a, b, d, l, rw, fc, fi, fo = row
    print(f"  {a:>2} -> {b:>2}      {d:>7}  {l:>5}  {rw:>8}  "
          f"{fc:>6}  {fi:>5}  {fo:>6}")

# ─────────────────────────────────────────────
# 6. WRITE  sd_pairs.csv  (with vehicle_type)
# ─────────────────────────────────────────────
# Each S-D pair is assigned a vehicle type from the list.
# This creates a diverse mix of vehicle types across pairs.
sd_pairs = [
    (0, 9), (0, 7), (0, 3),
    (1, 8), (1, 9),
    (2, 8), (2, 9),
    (3, 9),
    (4, 7), (4, 9),
    (5, 9),
    (6, 9),
    (7, 0), (7, 9),
    (8, 1),
    (9, 0), (9, 3),
]

# Assign vehicle types: cycle through the list for full coverage,
# then randomly assign the rest
assigned_types = []
for i, (src, dst) in enumerate(sd_pairs):
    if i < len(vehicle_types_list):
        vtype = vehicle_types_list[i]
    else:
        vtype = random.choice(vehicle_types_list)
    assigned_types.append(vtype)

with open("sd_pairs.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["source", "destination", "vehicle_type"])
    for i, (src, dst) in enumerate(sd_pairs):
        writer.writerow([src, dst, assigned_types[i]])

print(f"\n[OK] sd_pairs.csv -- {len(sd_pairs)} source-destination pairs written (with vehicle_type)")
print("\nVehicle type assignments:")
for i, (src, dst) in enumerate(sd_pairs):
    print(f"  P{i}: {src} -> {dst}  vehicle={assigned_types[i]}")

print("\n[OK] Dataset generation complete.")
print("    Files produced: nodes.csv, map_data.csv, sd_pairs.csv, vehicle_types.csv")
print("    Place all files alongside the compiled executable.\n")
