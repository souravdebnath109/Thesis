"""
Generate corrected fixed_flowchart.png that matches updated_flowchart.png structure
but uses fixed alpha/beta/rho instead of PSO.

Both Step A (Independent) and Step B (Combined Route Optimization) must be present.
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

fig, ax = plt.subplots(1, 1, figsize=(18, 28))
ax.set_xlim(0, 18)
ax.set_ylim(0, 28)
ax.set_aspect('equal')
ax.axis('off')

# Colors
C_START   = '#27ae60'   # green
C_END     = '#e74c3c'   # red
C_PROCESS = '#2c3e50'   # dark blue
C_DECISION= '#1a5276'   # blue
C_IO      = '#117864'   # teal
C_UPDATE  = '#6c7a3a'   # olive
C_PHASE   = '#1f618d'   # navy
C_LABEL   = '#2c3e50'
C_SECTION = '#1B4F72'
C_BG_BOX  = '#eaf2f8'
C_YES     = '#27ae60'
C_NO      = '#c0392b'

def draw_box(ax, cx, cy, w, h, text, color=C_PROCESS, fontsize=7.5,
             shape='round', facecolor='white', text_color='white', alpha=1.0):
    """Draw a rounded box with centered text."""
    if shape == 'round':
        box = FancyBboxPatch((cx-w/2, cy-h/2), w, h,
              boxstyle="round,pad=0.08", facecolor=color, edgecolor=color,
              linewidth=1.5, alpha=alpha, zorder=3)
        ax.add_patch(box)
        ax.text(cx, cy, text, ha='center', va='center', fontsize=fontsize,
                color=text_color, fontweight='bold', zorder=4, wrap=True,
                linespacing=1.3)
    elif shape == 'diamond':
        w2, h2 = w*0.7, h*0.7
        diamond = plt.Polygon([
            (cx, cy+h2/2), (cx+w2/2, cy), (cx, cy-h2/2), (cx-w2/2, cy)
        ], facecolor=color, edgecolor=color, linewidth=1.5, alpha=alpha, zorder=3)
        ax.add_patch(diamond)
        ax.text(cx, cy, text, ha='center', va='center', fontsize=fontsize-0.5,
                color=text_color, fontweight='bold', zorder=4, linespacing=1.2)
    elif shape == 'parallelogram':
        dx = 0.3
        para = plt.Polygon([
            (cx-w/2+dx, cy+h/2), (cx+w/2+dx, cy+h/2),
            (cx+w/2-dx, cy-h/2), (cx-w/2-dx, cy-h/2)
        ], facecolor=color, edgecolor=color, linewidth=1.5, alpha=alpha, zorder=3)
        ax.add_patch(para)
        ax.text(cx, cy, text, ha='center', va='center', fontsize=fontsize,
                color=text_color, fontweight='bold', zorder=4, linespacing=1.3)
    elif shape == 'stadium':
        box = FancyBboxPatch((cx-w/2, cy-h/2), w, h,
              boxstyle="round,pad=0.15", facecolor=color, edgecolor='white',
              linewidth=2, alpha=alpha, zorder=3)
        ax.add_patch(box)
        ax.text(cx, cy, text, ha='center', va='center', fontsize=fontsize,
                color=text_color, fontweight='bold', zorder=4, linespacing=1.3)

def arrow(ax, x1, y1, x2, y2, label=None, color='#2c3e50', lw=1.5,
          label_color=None, label_offset=(0,0)):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=color, lw=lw, zorder=2))
    if label:
        mx = (x1+x2)/2 + label_offset[0]
        my = (y1+y2)/2 + label_offset[1]
        lc = label_color or (C_YES if label=='YES' else C_NO if label=='NO' else C_LABEL)
        ax.text(mx, my, label, ha='center', va='center', fontsize=7,
                fontweight='bold', color=lc, zorder=5,
                bbox=dict(boxstyle='round,pad=0.1', fc='white', ec='none', alpha=0.9))

def section_bar(ax, y, text, width=8):
    cx = 6
    ax.add_patch(FancyBboxPatch((cx-width/2, y-0.2), width, 0.4,
                 boxstyle="round,pad=0.05", facecolor=C_SECTION, edgecolor=C_SECTION,
                 linewidth=2, zorder=3))
    ax.text(cx, y, text, ha='center', va='center', fontsize=9,
            color='white', fontweight='bold', zorder=4)

# ─────────────────────────────────────────────────────────────────────────────
# TITLE
# ─────────────────────────────────────────────────────────────────────────────
ax.text(9, 27.5,
    "Dynamic Path Planning Based on Improved ACO Algorithm\n"
    "(Fixed α, β, ρ Parameters, Road Condition Factor R)\n"
    "with Combined Route Optimization & Vehicle Type Constraint",
    ha='center', va='center', fontsize=11, fontweight='bold', color=C_LABEL)

# ─────────────────────────────────────────────────────────────────────────────
# START
# ─────────────────────────────────────────────────────────────────────────────
X = 6  # center x for step A
draw_box(ax, X, 26.6, 1.5, 0.4, 'START', color=C_START, fontsize=8)
arrow(ax, X, 26.4, X, 26.05)

# Load Config
draw_box(ax, X, 25.8, 5.5, 0.45, 'Load Config, Map Data, S-D Pairs, Vehicle Types\n'
         'Load config.txt, map_data.csv, sd_pairs.csv, vehicle_types.csv',
         color=C_IO, fontsize=6.5)
arrow(ax, X, 25.55, X, 25.25)

# Compute R
draw_box(ax, X, 25.0, 5.0, 0.45, 'Compute Initial Road Condition Factors\n'
         'R_i(0) = d_i × (1 + C_i)   using vehicle-specific L',
         color=C_PROCESS, fontsize=6.5)
arrow(ax, X, 24.75, X, 24.45)

# Validate
draw_box(ax, X, 24.2, 4.0, 0.4, 'Validate S-D Pairs + Vehicle Types',
         color=C_PROCESS, fontsize=7)
arrow(ax, X, 24.0, X, 23.65)

# ─────── STEP A SECTION ──────
section_bar(ax, 23.4, 'STEP A: INDEPENDENT OPTIMIZATION (Fixed α, β, ρ)')
arrow(ax, X, 23.2, X, 22.85)

# FOR each pair
draw_box(ax, X, 22.6, 5.2, 0.4, 'FOR each S-D pair (independent) — with vehicle type',
         color=C_SECTION, fontsize=7, text_color='white')
arrow(ax, X, 22.4, X, 22.0)

# Load fixed params (REPLACES PSO)
draw_box(ax, X, 21.7, 5.0, 0.55,
         'Load Fixed ACO Parameters\n'
         'Use pre-defined fixed values: α, β, ρ from\n'
         'config.txt (No PSO optimization)',
         color='#2874a6', fontsize=6.5, text_color='white')
arrow(ax, X, 21.4, X, 21.05)

# Phase 2 - Initial ACO
draw_box(ax, X, 20.75, 5.0, 0.55,
         'Initial ACO Pathfinding\n'
         'Run ACO with fixed (α, β, ρ) + vehicle constraint\n'
         'Use R_i(t) to replace d_i. Generate initial besttour',
         color=C_PHASE, fontsize=6.5)
arrow(ax, X, 20.45, X, 20.1)

# Dynamic monitoring
draw_box(ax, X, 19.8, 5.0, 0.5,
         'Dynamic Monitoring (t → t+1)\n'
         'Update R_i(t) and ΔR_i = R_i(t+1) − R_i(t)',
         color=C_PROCESS, fontsize=6.5)
arrow(ax, X, 19.55, X, 19.15)

# Trigger decision
draw_box(ax, X, 18.85, 5.5, 0.5,
         'Trigger condition?\n'
         '(ΔR_i > ΔR_max) OR (R_i(t) > R_max)',
         color=C_DECISION, fontsize=6.5, shape='round')
# NO arrow left
arrow(ax, X-2.75, 18.85, X-4.0, 18.85, label='NO')
ax.text(X-4.8, 18.85, 'Proceed on\nexisting besttour', ha='center', va='center',
        fontsize=6, color=C_LABEL, style='italic')

# YES arrow down
arrow(ax, X, 18.6, X, 18.2, label='YES')

# Re-plan
draw_box(ax, X, 17.9, 5.0, 0.5,
         'Re-plan from current node\n'
         'using ACO with fixed (α, β, ρ)\n'
         '+ vehicle type constraint. Compute newtour',
         color=C_PHASE, fontsize=6.5)
arrow(ax, X, 17.6, X, 17.2)

# Is newtour better?
draw_box(ax, X, 16.9, 5.0, 0.5,
         'Is newtour better?\n'
         'newtour < (besttour − a_r)\n'
         '(a_r: traversed path cost so far)',
         color=C_DECISION, fontsize=6.5)

# NO right
arrow(ax, X+2.5, 16.9, X+4.0, 16.9, label='NO')
# Loop NO back up to dynamic monitoring
ax.annotate('', xy=(X+4.0, 19.8), xytext=(X+4.0, 16.9),
            arrowprops=dict(arrowstyle='->', color=C_NO, lw=1.5))

# YES down
arrow(ax, X, 16.6, X, 16.2, label='YES')

# Update
draw_box(ax, X, 15.9, 4.5, 0.5,
         'YES Update:\n'
         'besttour ← newtour + a_r\n'
         'a_r = a_r + R_i(t)',
         color=C_UPDATE, fontsize=6.5, text_color='white')
arrow(ax, X, 15.6, X, 15.2)

# Traverse
draw_box(ax, X, 14.9, 4.5, 0.4,
         'Traverse next road segment\nalong selected tour',
         color=C_PROCESS, fontsize=6.5)
arrow(ax, X, 14.7, X, 14.3)

# Reached endpoint?
draw_box(ax, X, 14.0, 4.0, 0.4,
         'Reached endpoint?',
         color=C_DECISION, fontsize=7)

# NO loops back to dynamic monitoring
arrow(ax, X-2.0, 14.0, X-4.5, 14.0, label='NO')
ax.annotate('', xy=(X-4.5, 19.8), xytext=(X-4.5, 14.0),
            arrowprops=dict(arrowstyle='->', color=C_NO, lw=1.3))

# YES down
arrow(ax, X, 13.8, X, 13.4, label='YES')

# Save Pair Result
draw_box(ax, X, 13.1, 3.5, 0.4, 'Save Pair Result',
         color=C_IO, fontsize=7.5)
arrow(ax, X, 12.9, X, 12.5)

# ─────── STEP B SECTION ──────
section_bar(ax, 12.25, 'STEP B: COMBINED ROUTE OPTIMIZATION', width=8)
arrow(ax, X, 12.05, X, 11.65)

# Combined enabled?
draw_box(ax, X, 11.35, 4.5, 0.45,
         'combined_opt enabled?',
         color=C_DECISION, fontsize=7.5)

# NO → right to END
arrow(ax, X+2.25, 11.35, X+4.5, 11.35, label='NO')
draw_box(ax, X+5.5, 11.35, 1.5, 0.4, 'END\n(Skip)', color=C_END, fontsize=7)

# YES down
arrow(ax, X, 11.1, X, 10.7, label='YES')

# FOR each combined iter
draw_box(ax, X, 10.4, 5.0, 0.4,
         'FOR each combined iteration k',
         color=C_SECTION, fontsize=7.5, text_color='white')
arrow(ax, X, 10.2, X, 9.8)

# Apply aggregate traffic
draw_box(ax, X, 9.5, 5.5, 0.5,
         'Apply Aggregate Traffic\n'
         'increase shared edges (freq ≥ 2):\n'
         'increase f_current by weight × (freq − 1)',
         color=C_PHASE, fontsize=6.5)
arrow(ax, X, 9.2, X, 8.8)

# Run all pairs
draw_box(ax, X, 8.5, 5.5, 0.55,
         'FOR each S-D pair: run_single_pair\n'
         '(Fixed α,β,ρ → ACO → Dynamic Re-planning)\n'
         'with vehicle type constraint',
         color=C_PROCESS, fontsize=6.5)
arrow(ax, X, 8.2, X, 7.8)

# Compute stats
draw_box(ax, X, 7.5, 5.0, 0.45,
         'Compute Iteration Statistics\n'
         'avg_cost, cost_change_%, route_changes',
         color=C_PROCESS, fontsize=6.5)
arrow(ax, X, 7.25, X, 6.85)

# Stabilized?
draw_box(ax, X, 6.55, 4.5, 0.45,
         'Stabilized?\n'
         'cost_change < stability_threshold (5%)',
         color=C_DECISION, fontsize=6.5)

# NO loops back up
arrow(ax, X+2.25, 6.55, X+4.2, 6.55, label='NO')
ax.annotate('', xy=(X+4.2, 10.4), xytext=(X+4.2, 6.55),
            arrowprops=dict(arrowstyle='->', color=C_NO, lw=1.5))

# YES down
arrow(ax, X, 6.3, X, 5.85, label='YES')

# Save combined results
draw_box(ax, X, 5.5, 5.5, 0.6,
         'Save Combined Results & Comparison Report\n'
         'combined_pairs_results.csv\n'
         'network_analysis_combined.txt\n'
         'combined_comparison.txt',
         color=C_IO, fontsize=6.5)
arrow(ax, X, 5.15, X, 4.75)

# END
draw_box(ax, X, 4.45, 3.5, 0.5,
         'END\nOutput final stabilized routes',
         color=C_END, fontsize=7.5, text_color='white')

# ─── Annotation box (right side) ───
annot_x = 13.5
annot_y = 20.5
ax.add_patch(FancyBboxPatch((annot_x-2.2, annot_y-1.5), 4.8, 3.2,
             boxstyle="round,pad=0.15", facecolor='#eaf2f8', edgecolor=C_SECTION,
             linewidth=1.5, zorder=2))
ax.text(annot_x, annot_y+1.2, 'Fixed Parameter Architecture:', ha='center',
        va='center', fontsize=7.5, fontweight='bold', color=C_SECTION, zorder=4)
annotations = [
    '• Fixed α, β, ρ loaded from config',
    '• ACO performs pathfinding & dynamic',
    '  re-planning with vehicle constraint',
    '• No parameter optimization step',
    '• Same pipeline except PSO is skipped',
    '• Combined optimization adds outer',
    '  loop for network-aware balancing',
    '• Vehicle type filters illegal edges',
]
for i, line in enumerate(annotations):
    ax.text(annot_x, annot_y+0.7 - i*0.3, line, ha='center', va='center',
            fontsize=6.2, color=C_LABEL, zorder=4)

plt.savefig('fixed_flowchart.png', dpi=180, bbox_inches='tight',
            facecolor='white', edgecolor='none')
print("[OK] Saved fixed_flowchart.png")
